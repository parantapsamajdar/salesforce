package testscripts.insurnace_demo;
import org.testng.annotations.Test;



import pages.AccountScreen;
//import pages.LoginScreen;
import SFDC.SeleniumWrapper;

import com.cognizant.framework.CraftliteDataTable;
import com.cognizant.framework.IterationOptions;
import com.cognizant.framework.Report;
import com.cognizant.framework.Status;

import supportlibraries.DriverScript;
import supportlibraries.TestCase;
import functionallibraries.FunctionalLibrary;


/**
 * Test for login with valid user credentials
 * @author Cognizant
 */
public class TC02_CreateClientInc extends TestCase
{
	private FunctionalLibrary functionalLibrary;
	SeleniumWrapper sfdc;
	@Test
	public void runTC02_CreateClientInc()
	{
		testParameters.setCurrentTestDescription("Test for login with valid user credentials");
		testParameters.setIterationMode(IterationOptions.RunOneIterationOnly);
		driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
	}
	
	@Override
	public void setUp()
	{
		functionalLibrary = new FunctionalLibrary(scriptHelper);
		report.addTestLogSection("Setup");
		sfdc=new SeleniumWrapper(scriptHelper);
		sfdc.openURL("https://login.salesforce.com");
	}
	
	@Override
	public void executeTest()
	{
		try {
			
			Thread.sleep(10000);
			sfdc.findElementByXpath("//input[@id='username']", "Username").type("cognizant.qeacrm@sfdc.com");
			sfdc.findElementByXpath("//input[@id='password']", "Password").type("Cognizant@16");
			sfdc.findElementByXpath("//input[@id='Login']", "Clicking Login button").click();	
			
			
			Thread.sleep(10000);
			sfdc.findElementByXpath("//div[@id='tsid-arrow']", "Org Selection").click();
			//driver.findElement(By.xpath("//a[@title='Setup']"));
			Thread.sleep(10000);
			if(sfdc.findElementByXpath("//a[@href='home/home.jsp?tsid=02u610000001wvr']", "Org Click").isElementPresent())
			{
				sfdc.findElementByXpath("//a[@href='home/home.jsp?tsid=02u610000001wvr']", "Org Click").click();
			}
			Thread.sleep(10000);
			sfdc.selectTab("Accounts");
			
			sfdc.findElementByXpath("//input[@title='New']", "Clicking New button").click();
			Thread.sleep(10000);
			//Code without capturing Object Repository
			/*Thread.sleep(10000);
			sfdc.findElementByXpath("//input[@id='acc2']", "Account Name").type("Demo_Client");
			sfdc.findElementByXpath("//select[@id='acc9']", "Rating").selectByValue("Hot");
			sfdc.findElementByXpath("//input[@id='acc10']", "Phone Number").type("1234567890");
			sfdc.findElementByXpath("//select[@id='acc6']", "Type").selectByValue("Prospect");
			Thread.sleep(10000);
			sfdc.findElementByXpath("//input[@title='Save']", "Clicking New button").click();*/
			
			//Code With Object Repository
			AccountScreen acc=new AccountScreen(scriptHelper);
			acc.AccountNameTextbox().type("Reposit123");
			acc.RatingDropDown().selectByValue("Hot");
			acc.PhoneTextbox().type("123456700");
			acc.TypeDropDown().selectByValue("Prospect");
			Thread.sleep(10000);
			acc.SaveButton().click();
			}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Override
	public void tearDown()
	{
		// Nothing to do
	}
}