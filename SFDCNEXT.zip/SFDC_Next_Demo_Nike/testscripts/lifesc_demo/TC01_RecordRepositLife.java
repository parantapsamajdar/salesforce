package testscripts.lifesc_demo;

import org.testng.annotations.Test;


import SFDC.SeleniumWrapper;

import com.cognizant.framework.CraftliteDataTable;
import com.cognizant.framework.IterationOptions;
import com.cognizant.framework.Report;
import com.cognizant.framework.Status;

import supportlibraries.DriverScript;
import supportlibraries.TestCase;
import functionallibraries.FunctionalLibrary;


/**
 * Test for login with valid user credentials
 * @author Cognizant
 */
public class TC01_RecordRepositLife extends TestCase
{
	private FunctionalLibrary functionalLibrary;
	SeleniumWrapper sfdc;
	@Test
	public void runTC01_RecordRepositLife()
	{
		testParameters.setCurrentTestDescription("Test for login with valid user credentials");
		testParameters.setIterationMode(IterationOptions.RunOneIterationOnly);
		driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
	}
	
	@Override
	public void setUp()
	{
		functionalLibrary = new FunctionalLibrary(scriptHelper);
		report.addTestLogSection("Setup");
		sfdc=new SeleniumWrapper(scriptHelper);
		sfdc.openURL("https://login.salesforce.com");
		//report.updateTestLog("Invoke Application", "Invoke the application under test @ " +
								//properties.getProperty("ApplicationUrl"), Status.DONE);
	}
	
	@Override
	public void executeTest()
	{
		try
		{
			Thread.sleep(10000);
			sfdc.findElementByXpath("//input[@id='username']", "Username").type("cognizant.qeacrm@sfdc.com");
			sfdc.findElementByXpath("//input[@id='password']", "Password").type("Cognizant@16");
			sfdc.findElementByXpath("//input[@id='Login']", "Clicking Login button").click();	
			
			
			Thread.sleep(10000);
			sfdc.findElementByXpath("//div[@id='tsid-arrow']", "Org Selection").click();
			//driver.findElement(By.xpath("//a[@title='Setup']"));
			Thread.sleep(10000);
			if(sfdc.findElementByXpath("//a[@href='/home/home.jsp?tsid=02u610000001wvw']", "Org Click").isElementPresent())
			{
				sfdc.findElementByXpath("//a[@href='/home/home.jsp?tsid=02u610000001wvw']", "Org Click").click();
			}
			///
			Thread.sleep(10000);
			//sfdc.window().changeURLto("https://na34.salesforce.com/a0161000005k5Co");
			//Thread.sleep(5000);
			//sfdc.createRepositoryFromRecord("MyAccount");
			
			sfdc.window().changeURLto("https://na34.salesforce.com/a0261000003UMEa");
			Thread.sleep(5000);
			sfdc.createRepositoryFromRecord("Survey");
		}
		
	//	
		/*LoginScreen login=new LoginScreen(scriptHelper);
		//AccountsScreen account=new AccountsScreen(scriptHelper);
		//String accountName;
		String userName=dataTable.getData("General_Data", "Username"); // get test data from excel
		String password=dataTable.getData("General_Data", "Password");  // get test data from excel
		//String accountNumber=dataTable.getData("Account", "accountNumber"); // get test data from excel
		//String accountOwner=dataTable.getData("Account", "accountOwner");   // get test data from excel
		/*System.out.println(dataTable.getData("General_Data", "Username"));
		System.out.println(password);
		try {
			//Thread.sleep(5000);
			login.login(userName, password);//Login to SSO application
			/* if (sfdc.findElementByXpath("name=answer1", "Security Question").isElementPresent())
			 { 
				//report.updateTestLog("Login Credtinals", "Valid External Userid and Password", Status.PASS);
				//sfdc.findElementByXpath("//*[@id='showanswer1']", "Security Question").type("mom");
				//sfdc.findElementByXpath("//*[@id='showanswer2']", "Security Question").type("mom");			 		
			 	//sfdc.findElementByXpath("id=challengeUserForm_registerDevicePublic computer (Library, Coffee Shop, Client Computer etc.)", "Option BUtton CLick").click();			 	
			 	//sfdc.findElementByXpath("//*[@id='challengeUserForm_0']", "Submit Button Click").click();
			 	Thread.sleep(5000);
			 	/*sfdc.findElementByXpath("className=allTabsArrow", "All Tab click").click();
			 	sfdc.findElementByXpath("title=DC Book", "DC Tab click").click();;
			 	
			 }*/
			 	/*if (sfdc.findElementByXpath("//a[@title='Home Tab - Selected']", "Login Validation").isElementPresent())
			 	{
			 		report.updateTestLog("Application Login Using SSO", "Login Successful Using external login", Status.PASS);
			 	}
			 	else
			 	{
			 		report.updateTestLog("Application Login Using SSO", "Login unsuccessful Using external login", Status.FAIL);
			 	}*/
			 	//Thread.sleep(50000);
			 	//sfdc.findElementByXpath("id=sbstr","SSN Pass").type(dataTable.getData("General_Data", "SSN"));*/
			 	
			 	//String clientName=dataTable.getData("General_Data", "Clientname"); 
			 	//System.out.println(dataTable.getData("General_Data", "Clientname"));
			 	
			 	//sfdc.searchGlobal(dataTable.getData("General_Data", "SSN"));
			 	/*sfdc.findElementByXpath("//input[@value=' Go! ']","Clicking on go button").click();
			 	Thread.sleep(5000);
			 	sfdc.findElementByXpath("//div[@id='Account_body']/table/tbody/tr[2]/th/a","Clicking client").click();
			 	///html/body/div/div[2]/table/tbody/tr/td[2]/div[4]/div/div/div[2]/div/div[2]/table/tbody/tr[2]/th/a
			 	sfdc.findElementByXpath("//input[@value='Client 360 View']","Clicking on client 360 button").click();
			 	
			 	//sfdc.findElementByXpath("//a[@innertext='" + clientName + "']", "Click On Client Link").click();
			 	//System.out.println(sfdc.findElementByXpath("//a[@innertext='" + clientName + "']", "Click On Client Link"));
			 	//Thread.sleep(50000);
			 	
			 	//System.out.println(sfdc.window().getPageSource());
			 	//System.out.println("in the frame");
			 	//System.out.println(sfdc.findElementByXpath("//select[@id='prName']", "DC Book Page validation").getValues().toString());
			 	/*if(sfdc.findElementByXpath("//input[@id='btnClear']", "Retail Book Page validation").isElementPresent())
			 	{
			 		report.updateTestLog("Retail Book Page Validation", "Retail Book Opening Succesfully", Status.PASS);
			 	}
			 	else
			 	{
			 		report.updateTestLog("Retail Book Page Validation", "Retail Book Not Working", Status.FAIL);
			 	}/*
			 	//System.out.println("Text1");
			 	sfdc.window().selectDefault();*/
			 
			  catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Override
	public void tearDown()
	{
		// Nothing to do
	}
}