package testscripts.lifesc_demo;
import org.testng.annotations.Test;




import pages.MyAccountScreen;
import SFDC.SeleniumWrapper;

import com.cognizant.framework.CraftliteDataTable;
import com.cognizant.framework.IterationOptions;
import com.cognizant.framework.Report;
import com.cognizant.framework.Status;

import supportlibraries.DriverScript;
import supportlibraries.TestCase;
import functionallibraries.FunctionalLibrary;


/**
 * Test for login with valid user credentials
 * @author Cognizant
 */
public class TC02_CreateClientLife extends TestCase
{
	private FunctionalLibrary functionalLibrary;
	SeleniumWrapper sfdc;
	@Test
	public void runTC02_CreateClientLife()
	{
		testParameters.setCurrentTestDescription("Test for login with valid user credentials");
		testParameters.setIterationMode(IterationOptions.RunOneIterationOnly);
		driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
	}
	
	@Override
	public void setUp()
	{
		functionalLibrary = new FunctionalLibrary(scriptHelper);
		report.addTestLogSection("Setup");
		sfdc=new SeleniumWrapper(scriptHelper);
		sfdc.openURL("https://login.salesforce.com");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {			
			e.printStackTrace();
		}
		//report.updateTestLog("Invoke Application", "Invoke the application under test @ " +
								//properties.getProperty("ApplicationUrl"), Status.DONE);
	}
	
	@Override
	public void executeTest()
	{
		//LoginScreen login=new LoginScreen(scriptHelper);	
		
		
		try {
			Thread.sleep(10000);
			sfdc.findElementByXpath("//input[@id='username']", "Username").type("cognizant.qeacrm@sfdc.com");
			sfdc.findElementByXpath("//input[@id='password']", "Password").type("Cognizant@16");
			sfdc.findElementByXpath("//input[@id='Login']", "Clicking Login button").click();	
			
			Thread.sleep(10000);
			sfdc.findElementByXpath("//div[@id='tsid-arrow']", "Org Selection").click();
			//driver.findElement(By.xpath("//a[@title='Setup']"));
			Thread.sleep(10000);
			if(sfdc.findElementByXpath("//a[@href='/home/home.jsp?tsid=02u610000001wvw']", "Org Click").isElementPresent())
			{
				sfdc.findElementByXpath("//a[@href='/home/home.jsp?tsid=02u610000001wvw']", "Org Click").click();
			}
			
			Thread.sleep(10000);
			sfdc.selectTab("My Accounts");
			
			sfdc.findElementByXpath("//input[@title='New']", "Clicking New button").click();
			
			//Code without capturing Object Repository
			Thread.sleep(10000);
			/*sfdc.findElementByXpath("//input[@id='Name']", "My Account Name").type("MyAccount");//00N6100000COCMf
			sfdc.findElementByXpath("//input[@id='00N6100000COCMf']", "Parent Name").type("Hospital");//00N6100000COCMk
			sfdc.findElementByXpath("//input[@id='00N6100000COCMk']", "Short Name").type("MA");//00N6100000COCMp
			sfdc.findElementByXpath("//input[@id='00N6100000COCMp']", "Org Name").type("AMRI");
			sfdc.findElementByXpath("//input[@title='Save']", "Clicking New button").click();
			Thread.sleep(10000);*/
			
			//Code with capturing Object Repository
			MyAccountScreen ma=new MyAccountScreen(scriptHelper);
			ma.MyAccountNameTextbox().type("MyAccount123");
			ma.ParentNameTextbox().type("Parent Name");
			ma.ShortNameTextbox().type("MA123");
			ma.OrganisationTextbox().type("Fortis");
			ma.SaveButton().click();
			
			}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Override
	public void tearDown()
	{
		// Nothing to do
	}
}