package testscripts.bfs_demo;

import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;




import SFDC.SeleniumWrapper;

import com.cognizant.framework.CraftliteDataTable;
import com.cognizant.framework.IterationOptions;
import com.cognizant.framework.Report;
import com.cognizant.framework.Status;

import supportlibraries.DriverScript;
import supportlibraries.TestCase;
import functionallibraries.FunctionalLibrary;


/**
 * Test for login with valid user credentials
 * @author Cognizant
 */
public class TC01_RecordRepositBfs extends TestCase
{
	private FunctionalLibrary functionalLibrary;
	SeleniumWrapper sfdc;
	@Test
	public void runTC01_RecordRepositBfs()
	{
		testParameters.setCurrentTestDescription("Test for login with valid user credentials");
		testParameters.setIterationMode(IterationOptions.RunOneIterationOnly);
		driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
	}     
	
	@Override
	public void setUp()
	{
		functionalLibrary = new FunctionalLibrary(scriptHelper);
		report.addTestLogSection("Setup");
		sfdc=new SeleniumWrapper(scriptHelper);
		sfdc.openURL("https://login.salesforce.com");
		//report.updateTestLog("Invoke Application", "Invoke the application under test @ " +
								//properties.getProperty("ApplicationUrl"), Status.DONE);
	}
	public void executeTest()
	{
	
		try {
				Thread.sleep(10000);
				sfdc.findElementByXpath("//input[@id='username']", "Username").type("cognizant.qeacrm@sfdc.com");
				sfdc.findElementByXpath("//input[@id='password']", "Password").type("Cognizant@16");
				sfdc.findElementByXpath("//input[@id='Login']", "Clicking Login button").click();	
				
				Thread.sleep(10000);
				sfdc.findElementByXpath("//div[@id='tsid-arrow']", "Org Selection").click();
				//driver.findElement(By.xpath("//a[@title='Setup']"));
				Thread.sleep(10000);
				
				if(sfdc.findElementByXpath("//a[@href='/home/home.jsp?tsid=02u610000001wNE']", "Org Click").isElementPresent())
				{
					sfdc.findElementByXpath("//a[@href='/home/home.jsp?tsid=02u610000001wNE']", "Org Click").click();
				}
				Thread.sleep(10000);
				
				sfdc.window().changeURLto("https://na34.salesforce.com/a0061000005ANfx");
				Thread.sleep(5000);
				sfdc.createRepositoryFromRecord("Financial Account");
			 }
			  catch (Exception e) {
			e.printStackTrace();
			  }
		
	}
	
	@Override
	public void tearDown()
	{
		// Nothing to do
	}
}