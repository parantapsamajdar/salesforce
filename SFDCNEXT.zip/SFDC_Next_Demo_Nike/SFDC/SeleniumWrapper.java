package SFDC;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.cognizant.framework.Status;

import supportlibraries.ReusableLibrary;
import supportlibraries.ScriptHelper;

import java.awt.AWTException;
import java.awt.HeadlessException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

/**
 * Wrapper Class for selenium webdriver and Sales force dot com application OOTB functions
 * 
 * Extends {@link ReusableLibrary} class of the CRAFT 
 * 
 * @author Cognizant 
 */

public class SeleniumWrapper extends ReusableLibrary {
	public SeleniumWrapper(ScriptHelper scriptHelper) {
		super(scriptHelper);
		Javascript = ((JavascriptExecutor) driver);
	}


	private int numberOfTimesCommandRepeat;
	private String ElementIdentificatoin;
	private String xpath; // Holds the temp xpath of the element in the searchElement method
	private ArrayList<By> e = new ArrayList<By>();// driver By method array list
	private Set<String> temp_windows;// temp set variable used to manipulate the Window Handles
	private List<String> windows;// This holds sequential window handles 
	private JavascriptExecutor Javascript;//Java script executor instance
	private List<String> xpaths = new ArrayList<String>();// Xpaths if the user wants to search in multiple level
	private List<Integer> xpathindex = new ArrayList<Integer>();// holds xpath index of the xpath specified in the xpaths
	private List<String> xpathFieldMapping = new ArrayList<String>();// Field names
	private int time;// Threshold time of the dynamic wait
	private WebElement typeElement;// temp Webelement variable used for type command
	private String typeLabel;// temp Webelement variable used for type command
	


	/**
	 * 
	 * @author Cognizant
	 * @Description Takes screen print of the application and places in the path
	 *              provided with file name provided
	 * @return void
	 * @param FilePathwithFileNameAtEnd
	 *            File Path and FileName
	 * @throws AWTException 
	 * @throws HeadlessException 
	 */
	private void takeScreenPrint(String FilePathwithFileNameAtEnd)
			throws IOException, HeadlessException, AWTException {
		try{
		java.io.File scrFile = ((TakesScreenshot) driver)
				.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile, new java.io.File(""
				+ FilePathwithFileNameAtEnd + ".png"));
		}catch(Exception e){
			File file=new File(FilePathwithFileNameAtEnd+".png");
			file.mkdirs();
			new File(FilePathwithFileNameAtEnd+".png").createNewFile();
			BufferedImage image = new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
			ImageIO.write(image, "png", new File(FilePathwithFileNameAtEnd+".png"));
		}
	}
	
	/**
	 * execute java script on the window
	 * @author Cognizant
	 * @param Script
	 * 		  script to be executed
	 * @return Object
	 */
	public Object executeJavaScript(String Script) {
		return Javascript.executeScript(Script);
	}

	
	
	

	
	

	/**
	 * Alert Message commands
	 * @author Cognizant
	 * @return {@link Alert}
	 * @throws Exception 
	 */
	public Alert alert(){
		return new Alert();
	}
	/**
	 * Alert Message methods and user friendly commands
	 * @author Cognizant 
	 */
public class Alert{
	
	/**
	 * Click on the OK button in the alert <b>Note  : only Java scripts alerts</b>
	 * @author Cognizant
	 * @throws Exception 
	 */
	public void oKButtonClick() throws Exception {
		String stepName="Alert clickOKorYes";
		String alertText="";
		try{
		alertText=driver.switchTo().alert().getText();
		driver.switchTo().alert().accept();
		report.updateTestLog(stepName,"Clicked Alert message OK button: "+ alertText
		,Status.PASS);
		}catch(Exception e){
			report.updateTestLog(stepName,"Failed to Click on Alert message OK button: "+ alertText
			,Status.FAIL);
			//takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );   
			throw new Exception(e.getMessage());
		}
	}

	/**
	 * Click on the CANCEL button in the alert <b>Note  : only Java scripts alerts</b>
	 * @author Cognizant
	 * @throws Exception 
	 */
	public void cancelButtonClick() throws Exception {
		String stepName="Alert clickCancelorNo";
		String alertText="";
		try{
			alertText=driver.switchTo().alert().getText();
		driver.switchTo().alert().dismiss();
		report.updateTestLog(stepName,"Clicked Alert message Cancel button: "+ alertText
		,Status.PASS);
		}catch(Exception e){
			report.updateTestLog(stepName,"Failed to Click on Alert message Cancel button: "+alertText
			,Status.FAIL);
		//	takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );   
			throw new Exception(e.getMessage());
		}
	}

	/**
	 * returns the current open alert text present the message box <b>Note  : only Java scripts alerts</b>
	 * @author Cognizant
	 * @return String
	 */
	public String getAlertBoxMessage() {
		return (driver.switchTo().alert().getText());
	}

	
	/**
	 * returns true if the alert is present or false if the alert <b>Note  : only Java scripts alerts</b>
	 * @author Cognizant
	 * @return boolean
	 */
	public boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return (true);
		} catch (Exception e) {
			return (false);
		}
	}
}

	private final String TASKLIST = "tasklist";
	private final String KILL = "taskkill  /F /IM ";

	/**
	 * returns true if process running in the window service
	 * @author Cognizant
	 * @return boolean
	 */
	
		private boolean isProcessRunging(String serviceName) throws Exception {

		Process p = Runtime.getRuntime().exec(TASKLIST);
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				p.getInputStream()));
		String line;
		while ((line = reader.readLine()) != null) {

			if (line.contains(serviceName)) {
				return true;
			}
		}

		return false;

	}

	/**
	 * kills the processes if it is running
	 * @author Cognizant
	 * @param ProcessName
	 * 		  Process Name to be killed examples:  iexplore.exe, wordpad.exe
	 */
	public void killProcess(String serviceName) throws Exception {
		while (isProcessRunging(serviceName)) {
			Runtime.getRuntime().exec(KILL + serviceName);
		}
	}
	

/**
 * kills the processes if it is running like: chromedriver.exe,IEDriverServer.exe,iexplore.exe,firefox.exe,chrome.exe
 * @author Cognizant
 */
public void closeAllBrowsers() {
	try {
		killProcess("IEDriverServer.exe");
		killProcess("iexplore.exe");
		killProcess("firefox.exe");
		killProcess("chromedriver.exe");
		killProcess("chrome.exe");
	} catch (Exception e) {
	}
	
}



/**
 * finds element on the web page
 * @author Cognizant
 * @param XpathofElement
 * 			xpath of the element
 * @return {@link WebElementMethods}
 */

public WebElementMethods findElementByXpath(String XpathofElement,String identification) throws Exception {
	xpaths.clear();
	xpathindex.clear();
	xpathFieldMapping.clear();
	xpaths.add(XpathofElement);
	xpathFieldMapping.add(identification);
	time = 30;
	numberOfTimesCommandRepeat = 1;
	return new WebElementMethods();
}


/**
 * class level method to written to wait for page to load completely
 * @author Cognizant
 */
private void waitForComplete() throws Exception {
	try {
		String m = (String) executeJavaScript("function f(){return document.readyState;} return f();");
		while (!m.equalsIgnoreCase("complete")) {
			m = (String) executeJavaScript("function f(){return document.readyState;} return f();");
			Thread.sleep(1000);
		}
	} catch (Exception e) {
		//Thread.sleep(1000);
	}
}

/**
 * customs methods written on selenium to avoid runtime exceptions and user friendly methods for objects
 * @author Cognizant 
 */
public class WebElementMethods{
/**
 * used to add list values from unselected to selected
 * @author Cognizant
 * @param values
 * 		  Comma separated values
 */

public  void multiSelectAdd(String valuesWithSeperatedByHASH) throws Exception{
    String rootTempXpath=xpaths.get(0);
   String tempXpath;
    String fieldIndentification=xpathFieldMapping.get(0);
    String valuestobeselected[]= valuesWithSeperatedByHASH.split("#");
	for (String string : valuestobeselected) {
	   tempXpath=rootTempXpath+"//select[contains(@id,'_unselected')]";
	findElementByXpath(tempXpath, fieldIndentification).selectByValue(string);
	tempXpath=rootTempXpath+"//img[1]";
	findElementByXpath(tempXpath, fieldIndentification).click();
	}
}

/**
 * used to remove list values from selected to unselected
 * @author Cognizant
 * @param values
 * 		  Comma separated values
 */
public void multiSelectRemove(String valuesWithSeperatedByHASH) throws Exception {
    String rootTempXpath=xpaths.get(0);
    String tempXpath=rootTempXpath+"//select[contains(@id,'_selected')]";
     String fieldIndentification=xpathFieldMapping.get(0);
     String valuestobeselected[]= valuesWithSeperatedByHASH.split("#");
 	for (String string : valuestobeselected) {
 		findElementByXpath(tempXpath, fieldIndentification).selectByValue(string);
 	tempXpath=rootTempXpath+"//img[contains(@id,'left')]";
 	findElementByXpath(tempXpath, fieldIndentification).click();
 	}
    
}

/**
 * refers multi-select: unselected drop down
 * 
 * @author Cognizant
 * @return {@link WebElementMethods}
 */
public  WebElementMethods multiSelectUnSelected() throws Exception{
	String tempXpath=xpaths.get(0);
	tempXpath=tempXpath+"//select[contains(@id,'_unselected')]";
	String field = xpathFieldMapping.toString() + " multi-select: Un selected";
	return findElementByXpath(tempXpath, field);
}


/**
 * refers multi-select: selected drop down
 * @author Cognizant
 * @return {@link WebElementMethods}
 */
public  WebElementMethods multiSelectSelected() throws Exception{
	String tempXpath=xpaths.get(0);
	tempXpath=tempXpath+"//select[contains(@id,'_selected')]";
	String field = xpathFieldMapping.toString() + " multi-select : selected";
	return findElementByXpath(tempXpath, field);
}

/**
 * refers the error object in the path
 * @author Cognizant
 * @return {@link WebElementMethods}
 */

public WebElementMethods errorObject() throws Exception {
    String tempXpath=xpaths.get(0);
    tempXpath=tempXpath+"//div[@class='errorMsg']";
    xpaths.clear();
    String fieldIndentification=xpathFieldMapping.get(0);
    xpathFieldMapping.clear();
    return findElementByXpath(tempXpath, fieldIndentification);
}

/**
 * verifies if field is updated with error
 * @author Cognizant
 * @return boolean
 */

public boolean verifyErrorPresent() throws Exception {
    String stepName="verifyErrorPresent";
	String tempXpath=xpaths.get(0);
    tempXpath=tempXpath+"//div[@class='errorMsg']";
    xpaths.clear();
    String fieldIndentification=xpathFieldMapping.get(0);
    xpathFieldMapping.clear();
    
    if(findElementByXpath(tempXpath, fieldIndentification).isElementPresent()){
            report.updateTestLog(stepName,ElementIdentificatoin+" is updated with error message",Status.PASS);
            return true;
    }else{
    	report.updateTestLog(stepName,ElementIdentificatoin+" is not updated with error message",Status.FAIL);
            return false;
    }
}


/**
 * verifies if field is updated with expectd error message
 * @author Cognizant
 * @return boolean
 */

public boolean verifyErrorMessage(String expectedMessage) throws Exception {
	String stepName="verifyErrorMessage";
	String tempXpath=xpaths.get(0);
    tempXpath=tempXpath+"//div[@class='errorMsg']";
    xpaths.clear();
    String fieldIndentification=xpathFieldMapping.get(0)+" Error";
    xpathFieldMapping.clear();
    String ValueReturned=getValue().trim();
    
    if(expectedMessage.trim().equals(ValueReturned)){
            report.updateTestLog(stepName,ElementIdentificatoin+"The Expected Value:" + expectedMessage +" and Actual Values match"
            ,Status.PASS);
            return true;
    }else{
    	report.updateTestLog(stepName,ElementIdentificatoin+"The Expected Value:" + expectedMessage +" and Actual Value:"+ValueReturned+" miss match"
        ,Status.FAIL);
      //  takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );
            return false;
    }
}


	
	/**
	 * 
	 * execute java script on the element referred
	 * @author Cognizant
	 * @param Script
	 * 		  script to be executed
	 */
	public void executeJavaScriptOnElement(String Script) throws Exception {
		String stepName="executeJavaScriptOnElement";
		WebElement element; try{ element=searchElement();}catch(Exception e){report.updateTestLog("Run Time Error in "+stepName, e.getMessage(), Status.FAIL); throw new Exception(e.getMessage());}
		Javascript.executeScript(Script, element);
		xpaths.clear();
		xpathindex.clear();
		xpathFieldMapping.clear();
	}

	/**
	 * custom method to type values to Test Boxes or text area or any other element by clearing value
	 * @author Cognizant
	 * @param value
	 */

	public void type(String value) throws Exception {
		String stepName="type";
		String Logvalue=value;
		int length = 0;
		String m = internal_getValue();
		if (m != null) {
			length = m.length();
		}
		while (length > 0) {
			value = Keys.BACK_SPACE + value + Keys.DELETE;
			length--;
		}
		WebElement element;
		value = value + Keys.TAB;
		element = typeElement;
		String field=xpathFieldMapping.toString();
		for (int tm = 0; tm < numberOfTimesCommandRepeat; tm++) {
			try {
				element.sendKeys(value);
				report.updateTestLog(stepName,"Entered : " +typeLabel +" with value:"+ Logvalue
				,Status.PASS);
				xpaths.clear();
				xpathindex.clear();
				xpathFieldMapping.clear();
				break;
			} catch (Exception e) {
				if (numberOfTimesCommandRepeat == 4) {
					xpaths.clear();
					xpathindex.clear();
					xpathFieldMapping.clear();
					report.updateTestLog(stepName,"Failed to Entered : " +typeLabel +" with value:"+ Logvalue
					,Status.FAIL);
					//takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );   
					throw new Exception("Failed at:  " + field);
				}
				time = 30;
				try {
					type(value);
				} catch (Exception ee) {
				}

			}
		}
	

	}


	/**
	 *  Click on the element
	 * @author Cognizant
	 */

	public void click() throws Exception {
		String stepName="click";
		String Field=xpathFieldMapping.toString();
		WebElement element; try{ element=searchElement();}catch(Exception e){report.updateTestLog("Run Time Error in "+stepName, e.getMessage(), Status.FAIL); throw new Exception(e.getMessage());}
		try {
			element.click();
			report.updateTestLog(stepName,"Clicked on "+xpathFieldMapping.toString()
			,Status.PASS);
			xpaths.clear();
			xpathindex.clear();
			xpathFieldMapping.clear();
		} catch (Exception e) {
			//e.printStackTrace();
			if (e.getMessage().toLowerCase().contains("cannot")) {
				Javascript.executeScript("arguments[0].click()", element);
				xpaths.clear();
				xpathindex.clear();
				xpathFieldMapping.clear();
			} else {
				numberOfTimesCommandRepeat--;
				if (numberOfTimesCommandRepeat > 0) {
					Thread.sleep(1000);
					click();
				} else {
					report.updateTestLog(stepName,"could not click "+xpathFieldMapping.toString()
					,Status.FAIL);
					xpaths.clear();
					xpathindex.clear();
					xpathFieldMapping.clear();
					//takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );  
					throw new Exception("Failed at:  " + Field);
				}
			}
		}
	}


	/**
	 * select value from the drop down 
	 * @author Cognizant
	 * @param value
	 * 		  value to be selected from drop down, which is visible to the user
	 */
	public void selectByValue(String value) throws Exception {
		String stepName="selectByValue";
		String Field=xpathFieldMapping.toString();
		WebElement element;
		try{ element=searchElement();}catch(Exception e){report.updateTestLog("Run Time Error in "+stepName, e.getMessage(), Status.FAIL); throw new Exception(e.getMessage());}
		try {
			Select options = new Select(element);
			options.selectByVisibleText(value);
			/*for (WebElement option : options) {
				if(option.getText().trim().equals(value.trim())){
					option.click();
					found=true;fieldName="";
					break;
				}
			} */
			//if(found==true){
			report.updateTestLog(stepName,"Selected value:"+value +" from the drop down of the : "+ xpathFieldMapping.toString()
			,Status.PASS);
		//	}else{
		//		reportDetails.add("Failed to select value:"+value +" from the drop down of the : "+ xpathFieldMapping.toString());
		//		,Status.FAIL);
			//}
			xpaths.clear();
			xpathindex.clear();
			xpathFieldMapping.clear();
		} catch (Exception e) {
			numberOfTimesCommandRepeat--;
			if (numberOfTimesCommandRepeat > 0) {
				selectByValue(value);
			} else {
				report.updateTestLog(stepName,"Failed to select value:"+value +" from the drop down of the : "+ xpathFieldMapping.toString()
				,Status.FAIL);
				xpaths.clear();
				xpathindex.clear();
				xpathFieldMapping.clear();
				//takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );  
				throw new Exception("Failed at:  " + Field);
			}
		}
	}

	
	
	
	/**
	 * select value from the drop down 
	 * @author Cognizant
	 * @param value
	 * 		  value or index of the drop down value starts with '0'
	 */
	public void selectByIndex(int index) throws Exception {
		String stepName="selectByIndex";
		String Field=xpathFieldMapping.toString();
		WebElement element;
		try{ element=searchElement();}catch(Exception e){report.updateTestLog("Run Time Error in "+stepName, e.getMessage(), Status.FAIL); throw new Exception(e.getMessage());}
		try {
			Select options = new Select(element);
			options.selectByIndex(index);
			report.updateTestLog(stepName,"Selected option:"+index +" from the drop down  "+ xpathFieldMapping.toString()
			,Status.PASS);
			xpaths.clear();
			xpathindex.clear();
			xpathFieldMapping.clear();
		} catch (Exception e) {
			numberOfTimesCommandRepeat--;
			if (numberOfTimesCommandRepeat > 0) {
				selectByIndex(index);
			} else {
				report.updateTestLog(stepName,"Failed to select option:"+index +" from the drop down "+ xpathFieldMapping.toString()
				,Status.FAIL);
				xpaths.clear();
				xpathindex.clear();
				xpathFieldMapping.clear();
				//takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );  
				throw new Exception("Failed at:  " + Field);
			}
		}
	}


	/**
	 * returns the attribute value of the element
	 * @author Cognizant
	 * @param AttributeName
	 * @return String
	 */
	public String getAttributeValue(String AttributeName) throws Exception {
		WebElement element;
		ElementIdentificatoin=""+xpathFieldMapping.toString()+" ";
		String stepName="getAttributeValue";
		try{ element=searchElement();}catch(Exception e){report.updateTestLog("Run Time Error in "+stepName, e.getMessage(), Status.FAIL); throw new Exception(e.getMessage());}
		try {
			String m = element.getAttribute(AttributeName);
			xpaths.clear();
			xpathindex.clear();
			xpathFieldMapping.clear();
			return m;
		} catch (StaleElementReferenceException e) {
			numberOfTimesCommandRepeat--;
			if (numberOfTimesCommandRepeat > 0)
				getAttributeValue(AttributeName);
		} catch (NullPointerException e) {
			numberOfTimesCommandRepeat--;
			if (numberOfTimesCommandRepeat > 0)
				getAttributeValue(AttributeName);
		} catch (WebDriverException e) {
			numberOfTimesCommandRepeat--;
			if (numberOfTimesCommandRepeat > 0)
				getAttributeValue(AttributeName);

		} catch (Exception e) {
			numberOfTimesCommandRepeat--;
			if (numberOfTimesCommandRepeat > 0) {
				getAttributeValue(AttributeName);
			}
		}

		xpaths.clear();
		xpathindex.clear();
		xpathFieldMapping.clear();
		//takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );  
		throw new Exception("");
	}

	/**
	 *  returns value from the text box or text area or drop down 
	 * 				or text from non html controls like TD or DIV or SPAN etc 
	 * 				NOTE: This method is only used for type method
	 * @author Cognizant
	 * @return String
	 */
	private String internal_getValue() throws Exception {
		WebElement element;
		String stepName="type";
		try{ element=searchElement();}catch(Exception e){report.updateTestLog("Run Time Error in "+stepName, e.getMessage(), Status.FAIL); throw new Exception(e.getMessage());}
		typeElement = element;
		typeLabel=xpathFieldMapping.toString();
		String rvalue;
		try {
			if (element.getTagName().equalsIgnoreCase("input")) {
				rvalue = element.getAttribute("value");
				xpaths.clear();
				xpathindex.clear();
				xpathFieldMapping.clear();
				return rvalue;
			} else if (element.getTagName().equalsIgnoreCase("select")) {
				String value = element.getAttribute("value").toString();
				List<WebElement> SelectedOption = element.findElements(By
						.tagName("option"));
				for (WebElement webElement : SelectedOption) {
					if (webElement.getAttribute("value").toString()
							.equalsIgnoreCase(value)) {
						rvalue = webElement.getText();
						xpaths.clear();
						xpathindex.clear();
						xpathFieldMapping.clear();
						return rvalue;
					}
				}
				return "";
			} else {
				
				rvalue = element.getText();
				xpaths.clear();
				xpathindex.clear();
				xpathFieldMapping.clear();
				return rvalue;
			}
		} catch (StaleElementReferenceException e) {
			numberOfTimesCommandRepeat--;
			if (numberOfTimesCommandRepeat > 0)
				getValue();
		} catch (NullPointerException e) {
			numberOfTimesCommandRepeat--;
			if (numberOfTimesCommandRepeat > 0)
				getValue();
		} catch (WebDriverException e) {
			numberOfTimesCommandRepeat--;
			if (numberOfTimesCommandRepeat > 0)
				getValue();

		} catch (Exception e) {
			numberOfTimesCommandRepeat--;
			if (numberOfTimesCommandRepeat > 0) {
				getValue();
			}
		}
		return "";
	}

	
	/**
	 * 
	 * returns value from the text box or text area or drop down 
	 * or text from non html controls like TD or DIV or SPAN etc 
	 * @author Cognizant
	 * @return String
	 */
	public String getValue() throws Exception {
		WebElement element;
		String stepName="getValue";
		 try{ element=searchElement();}catch(Exception e){report.updateTestLog("Run Time Error in "+stepName, e.getMessage(), Status.FAIL); throw new Exception(e.getMessage());}
		typeElement = element;
		typeLabel=xpathFieldMapping.toString();
		ElementIdentificatoin=""+typeLabel+" ";
		String rvalue;
		String tagname=element.getTagName();
		try {
			if (tagname.equalsIgnoreCase("input")) {
				rvalue = element.getAttribute("value");
				//report.updateTestLog(stepName,"Value is retrieved from the applicaiton for :"+xpathFieldMapping.toString() +":"+rvalue);
				//,Status.PASS);
				xpaths.clear();
				xpathindex.clear();
				xpathFieldMapping.clear();
				return rvalue;
			} else if (tagname.equalsIgnoreCase("select")) {
				String value = element.getAttribute("value").toString();
				List<WebElement> SelectedOption = element.findElements(By
						.tagName("option"));
				for (WebElement webElement : SelectedOption) {
					if (webElement.getAttribute("value").toString()
							.equalsIgnoreCase(value)) {
						rvalue = webElement.getText();
					//	report.updateTestLog(stepName,"Value is retrieved from the applicaiton for :"+xpathFieldMapping.toString() +":"+rvalue);
					//	,Status.PASS);
						xpaths.clear();
						xpathindex.clear();
						xpathFieldMapping.clear();
						return rvalue;
					}
				}
				return "";
			} else {
				if(executeJavaScript("return navigator.appName;").toString().toLowerCase().contains("microsoft"))
				rvalue = element.getAttribute("innerText");
				else
				rvalue = element.getText();
				//report.updateTestLog(stepName,"Value is retrieved from the applicaiton for :"+xpathFieldMapping.toString() +":"+rvalue);
				//,Status.PASS);
				xpaths.clear();
				xpathindex.clear();
				xpathFieldMapping.clear();
				return rvalue;
			}
		} catch (StaleElementReferenceException e) {
			numberOfTimesCommandRepeat--;
			if (numberOfTimesCommandRepeat > 0)
				getValue();
		} catch (NullPointerException e) {
			numberOfTimesCommandRepeat--;
			if (numberOfTimesCommandRepeat > 0)
				getValue();
		} catch (WebDriverException e) {
			numberOfTimesCommandRepeat--;
			if (numberOfTimesCommandRepeat > 0)
				getValue();

		} catch (Exception e) {
			numberOfTimesCommandRepeat--;
			if (numberOfTimesCommandRepeat > 0) {
				getValue();
			}
		}
		//report.updateTestLog(stepName,"Failed to Get the value for the :"+xpathFieldMapping.toString());
		//,Status.FAIL);
		return "";
	}


	/**
	 * returns true if the element is present or false
	 * @author Cognizant
	 * @param WaitTime
	 * 		  Threshold time or wait time before returns true or false
	 * @return boolean
	 */
	public boolean isElementPresent(int WaitTime) throws Exception {
		time = WaitTime;
		webListofXpath();
		xpathFieldMapping.toString();
		for(int i=0;i<=time;i++){
				try{
					driver.findElement(e.get(0));// .get(nos.get(0));
					xpaths.clear();
					xpathindex.clear();
					xpathFieldMapping.clear();
					return true;
				
				} catch (Exception e) {
					if(i>=time){
						xpaths.clear();
						xpathindex.clear();
						xpathFieldMapping.clear();
						return false;
					}
					Thread.sleep(1000);
				}
		}
		return false;
	}
	
	
	/**
	 * returns true if the element is present or false and asserts it NOTE: not used
	 * @author Cognizant
	 * @param WaitTime
	 * 		   Threshold time or wait time before returns true or false
	 * @return boolean
	 */
	private boolean assertElementPresent(int WaitTime) throws Exception {
		String stepName="assertElementPresent";
		time = WaitTime;
		boolean found=false;
		String field=xpathFieldMapping.toString();
		webListofXpath();
		for(int i=0;i<=time;i++){
				try{
					driver.findElement(e.get(0));// .get(nos.get(0));
					xpaths.clear();
					xpathindex.clear();
					xpathFieldMapping.clear();
					return true;
				} catch (Exception e) {
					if(i>=time){
						xpaths.clear();
						xpathindex.clear();
						xpathFieldMapping.clear();
						if(found==false){
							report.updateTestLog(stepName,"Failed to Find Elemenet:"+field
							,Status.FAIL);
							//takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );   
							throw new Exception(field);
							}
					}else{
						found=false;
					}
					Thread.sleep(1000);
				}
		}
		return false;
		
	}
	

	/**
	 * returns true if the element is present or false
	 * @author Cognizant
	 * @return boolean
	 */
	public boolean isElementPresent() throws Exception {
	    waitForComplete();
		time = 1;
		String field=xpathFieldMapping.toString();
		ElementIdentificatoin=""+field+" ";
		//Thread.sleep(1000);
		webListofXpath();
		//for(int i=0;i<=time;i++){
				try{
					driver.findElement(e.get(0));// .get(nos.get(0));
					xpaths.clear();
					xpathindex.clear();
					xpathFieldMapping.clear();
					return true;
				
				} catch (Exception e) {
					//if(i>=time){
						xpaths.clear();
						xpathindex.clear();
						xpathFieldMapping.clear();
						return false;
					//}
					
				}
		//}
		//return false;

	}

	
	
	
	
	/**
	 * class level method to written to wait for element on the page to present with 
	 * 				polling of every 1 second
	 * @author Cognizant
	 */
	WebElement searchElement() throws Exception {
			webListofXpath();
			for(int i=0;i<time;i++){
			try {
			    	waitForComplete();
					return driver.findElement(e.get(0));// .get(nos.get(0));
				} catch (Exception ee) {
					ee.printStackTrace();
					Thread.sleep(1000);
				}
			}
			/*String field="Failed At:  " + xpathFieldMapping.toString();
			report.updateTestLog(stepName,"Failed find field/WebElement"+xpathFieldMapping.toString()
			,Status.FAIL);
			xpaths.clear();
			xpathindex.clear();
			xpathFieldMapping.clear();*/
			//takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );   
			throw new Exception("Failed find field/WebElement"+xpathFieldMapping.toString());
	}
	

	/**
	 * class level method to get xpath and update xpaths list based on the user input
	 * @author Cognizant
	 */
	void webListofXpath() throws Exception{
		e.clear();
		waitForComplete();
		for (int i = 0; i < xpaths.size(); i++) {
			xpath = xpaths.get(i);
			if (xpath.startsWith("id")) {
				xpath = xpath.substring(3);
				e.add(By.id(xpath));
			} else if (xpath.startsWith("name")) {
				xpath = xpath.substring(5);
				e.add(By.name(xpath));

			} else if (xpath.startsWith("link")) {
				xpath = xpath.substring(5);
				e.add(By.linkText(xpath));

			} else if (xpath.startsWith("tagname")) {
				xpath = xpath.substring(8);
				e.add(By.tagName(xpath));

			} else if (xpath.startsWith("class")) {
				xpath = xpath.substring(6);
				e.add(By.className(xpath));
			} else if (xpath.startsWith("css")) {
				xpath = xpath.substring(4);
				e.add(By.cssSelector(xpath));
			} else {
				e.add(By.xpath(xpath));
			}
		}
	}



	/**
	 *  returns number of xpaths matches
	 * @author Cognizant
	 * @return int
	 */
	public int count() {
		String stepName="count";
		int m = 0;
		for (int i = 0; i < time; i++) {
			try {
				m = driver.findElements(By.xpath(xpaths.get(0))).size();
				
				
			} catch (Exception e) {

			}
		}
		report.updateTestLog(stepName,"Number of element returened from the Application for field/Xpath: "+ xpathFieldMapping.toString()+"="+m
		,Status.PASS);
		xpaths.clear();
		xpathindex.clear();
		xpathFieldMapping.clear();
		return m;
	}

	
	
	

	/**
	 * focus on the element or navigate to element
	 * @author Cognizant
	 */
	public void navigatetoElement() throws Exception {
		WebElement element;
		String stepName="navigatetoElement";
		try{ element=searchElement();}catch(Exception e){report.updateTestLog("Run Time Error in "+stepName, e.getMessage(), Status.FAIL); throw new Exception(e.getMessage());}
		Actions builder = new Actions(driver);
		builder.moveToElement(element).build().perform();
	}

	/**
	 * returns drop down values as list
	 * @author Cognizant
	 * @return List<String>
	 */
	public List<String> getValues() throws Exception {
		WebElement element;
		String stepName="getValues";
		 try{ element=searchElement();}catch(Exception e){report.updateTestLog("Run Time Error in "+stepName, e.getMessage(), Status.FAIL); throw new Exception(e.getMessage());}
		ElementIdentificatoin=""+xpathFieldMapping.toString()+" ";
		try {
			while (!element.getAttribute("readyState").equalsIgnoreCase(
					"complete")) {
			}
		} catch (Exception e) {
		}
		try {
			if (element.getTagName().equalsIgnoreCase("select")) {
				List<WebElement> SelectedOption = element.findElements(By.tagName("option"));
				List<String> values =new ArrayList<String>();
				for (WebElement webElement : SelectedOption) {
					values.add(webElement.getText().trim());
				}
				xpaths.clear();
				xpathindex.clear();
				xpathFieldMapping.clear();
				return values;
			} else {
				xpaths.clear();
				xpathindex.clear();
				xpathFieldMapping.clear();
				return null;
			}
		} catch (StaleElementReferenceException e) {
			numberOfTimesCommandRepeat--;
			if (numberOfTimesCommandRepeat > 0)
				getValues();
		} catch (NullPointerException e) {
			numberOfTimesCommandRepeat--;
			if (numberOfTimesCommandRepeat > 0)
				getValues();
		} catch (WebDriverException e) {
			numberOfTimesCommandRepeat--;
			if (numberOfTimesCommandRepeat > 0)
				getValues();

		} catch (Exception e) {
			numberOfTimesCommandRepeat--;
			if (numberOfTimesCommandRepeat > 0) {
				getValues();
			}
		}
		xpaths.clear();
		xpathindex.clear();
		xpathFieldMapping.clear();
		return null;
	}

	/**
	 * hover overs on the element
	 * @author Cognizant
	 */
	public void hoverOver() throws Exception {
		WebElement element;
		String stepName="hoverOver";
		try{ element=searchElement();}catch(Exception e){report.updateTestLog("Run Time Error in "+stepName, e.getMessage(), Status.FAIL); throw new Exception(e.getMessage());}
		Actions action = new Actions(driver);
		Actions click = action.moveToElement(element, 10, 10);
		click.perform();
		xpaths.clear();
		xpathindex.clear();
		xpathFieldMapping.clear();
	}

	/**
	 * double click on the element
	 * @author Cognizant
	 */
	public void doubleClick() throws Exception {
	/*	Mouse mouse = ((HasInputDevices) driver).getMouse();
		WebElement element try{ element=searchElement();}catch(Exception e){report.updateTestLog("Run Time Error in "+stepName, e.getMessage(), Status.FAIL); throw new Exception(e.getMessage());}
		mouse.doubleClick((Coordinates) element.getLocation());*/
		WebElement element;
		String stepName="doubleClick";
		try{ element=searchElement();}catch(Exception e){report.updateTestLog("Run Time Error in "+stepName, e.getMessage(), Status.FAIL); throw new Exception(e.getMessage());}
		Actions action = new Actions(driver);
		Actions click = action.doubleClick(element);
		click.perform();
		xpaths.clear();
		xpathindex.clear();
		xpathFieldMapping.clear();
	}

	/**
	 * return true if textbox or textarea is editable
	 * @author Cognizant
	 * @return boolean
	 */
	public boolean isEditable() throws Exception {
		String m = null;
		try {
			m = getAttributeValue("disabled");
			xpaths.clear();
			xpathindex.clear();
			xpathFieldMapping.clear();
			if (m == null) {
				return true;
			}else{
				return false;	
			}
		} catch (Exception e) {
			xpaths.clear();
			xpathindex.clear();
			xpathFieldMapping.clear();
			return false;
		}
		
		
	}

	/**
	 * return true if textbox or textarea is editable and adds message in the Log
	 * @author Cognizant
	 * @return boolean
	 */
	public boolean verifyisEditable() throws Exception {
		String stepName="verifyisEditable";
		boolean ValueReturned=isEditable();
        if(ValueReturned){
                report.updateTestLog(stepName,ElementIdentificatoin+" is Editable"
                ,Status.PASS);
                return true;
        }else{
        	report.updateTestLog(stepName,ElementIdentificatoin+" is not Editable"
            ,Status.FAIL);
           // takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );
                return false;
        }
		
	}
	
	/**
	 * return true or false if textbox or textarea is editable and adds message in the Log 
	 * @author Cognizant
	 * @return boolean
	 */
	public boolean verifyisnotEditable() throws Exception {
		String stepName="verifyisnotEditable";
		boolean ValueReturned=isEditable();
        
        if(!ValueReturned){
                report.updateTestLog(stepName,ElementIdentificatoin+" is not Editable"
                ,Status.PASS);
                return true;
        }else{
        	report.updateTestLog(stepName,ElementIdentificatoin+" is Editable"
            ,Status.FAIL);
            //takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );
                return false;
        }
		
	}
	
	/**
	 * return true or false if textbox or textarea is Disabled
	 * @author Cognizant 
	 * @return boolean
	 */
	
	public boolean isDisabled() throws Exception {
		String m = null;
		try {
		m = getAttributeValue("disabled");
		if (m == null) {
		return false;
		}else{
			return true;
		}
		} catch (Exception e) {
			xpaths.clear();
			xpathindex.clear();
			xpathFieldMapping.clear();
			return false;
		}
		}

	/**
	 * return true if textbox or textarea is Disabled and adds Log Accordingly
	 * @author Cognizant
	 * @return boolean
	 */
	public boolean verifyisDisabled() throws Exception {
		String stepName="verifyisDisabled";
		boolean ValueReturned=isDisabled();
        
        if(ValueReturned){
                report.updateTestLog(stepName,ElementIdentificatoin+" is Disabeld"
                ,Status.PASS);
                return true;
        }else{
        	report.updateTestLog(stepName,ElementIdentificatoin+" is not Disabeld"
            ,Status.FAIL);
          //  takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );
                return false;
        }
		
	}
	
	
	/**
	 * returns true if the element is true or false and adds Log Accordingly 
	 * @author Cognizant
	 * @Description 
	 * @return boolean
	 */
	
	public boolean verifyisVisible() throws Exception{
		String stepName="verifyisVisible";
		boolean ValueReturned=isElementPresent();
		
		if(ValueReturned){
              report.updateTestLog(stepName,ElementIdentificatoin+" is visble"
              ,Status.PASS);
              return true;
      }else{
      	report.updateTestLog(stepName,ElementIdentificatoin+" is not visble"
          ,Status.FAIL);
         // takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );
              return false;
      }
		
	}
	
	/**
	 *  returns true if the element is present or false and adds Log Accordingly 
	 * @author Cognizant
	 * @return boolean
	 */
	
	public boolean verifyAttributeValue(String AttributeName,String AttributeValuetobeVerifyed) throws Exception{
		String stepName="verifyAttributeValue";
		String m = "";
		boolean ValueReturned=false;
		try {
			m = getAttributeValue(AttributeName);
			if (m == null || m.trim().equals("")) {
			}else{
				if(m.equals(AttributeValuetobeVerifyed)){
					ValueReturned=true;
				}
			}
		} catch (Exception e) {
			
		}
		
		
		if(ValueReturned){
              report.updateTestLog(stepName,ElementIdentificatoin+" Attribut Name: "+AttributeName+" Exptected AttributeValue: "+AttributeValuetobeVerifyed+" Match"
              ,Status.PASS);
              return true;
      }else{
    	  report.updateTestLog(stepName,ElementIdentificatoin+" Attribut Name: "+AttributeName+" Exptected AttributeValue: "+AttributeValuetobeVerifyed+" Actual AttributeValue: "+m+" Miss Match"
          ,Status.FAIL);
         // takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );
              return false;
      }
		
	}
	
	
	
	/**
	 * returns true if the element is present or false   and adds Log Accordingly 
	 * @author Cognizant
	 * @return boolean
	 */
	
	public boolean verifyisNotVisible() throws Exception{
		String stepName="verifyisNotVisible";
		boolean ValueReturned=isElementPresent();
		
		if(ValueReturned){
              report.updateTestLog(stepName,ElementIdentificatoin+" is visble"
              ,Status.FAIL);
            //  takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );
              return true;
      }else{
      	report.updateTestLog(stepName,ElementIdentificatoin+" is not visble"
          ,Status.PASS);
              return false;
      }
		
	}
	
	/**
	 * returns true if the element actual value equals to expected  and adds Log Accordingly 
	 * @author Cognizant
	 * @param ExpectedValue
	 * @return boolean
	 */
	public boolean verifyValue(String ExpectedValue) throws Exception {
		String stepName="VerifyValue";
        String ValueReturned=getValue().trim();
        
        if(ExpectedValue.trim().equals(ValueReturned)){
                report.updateTestLog(stepName,ElementIdentificatoin+"The Expected Value:" + ExpectedValue +" and Actual Values match"
                ,Status.PASS);
                return true;
        }else{
        	report.updateTestLog(stepName,ElementIdentificatoin+"The Expected Value:" + ExpectedValue +" and Actual Value:"+ValueReturned+" miss match"
            ,Status.FAIL);
          //  takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );
                return false;
        }
        
}
	
	
	/**
	 * returns true if the element actual value contains to expected  and adds Log Accordingly 
	 * @author Cognizant
	 * @param ExpectedValue
	 * @return boolean
	 */
	public boolean verifyValueContains(String value) throws Exception {
		String stepName="VerifyValueContains";
        String ValueReturned=getValue().trim();
        
        if(ValueReturned.trim().contains(value)){
                report.updateTestLog(stepName,ElementIdentificatoin+"The Expected Value:" + value +" is present in the Actual Value "+ValueReturned
                ,Status.PASS);
                return true;
        }else{
        	report.updateTestLog(stepName,ElementIdentificatoin+"The Expected Value:" + value +" is not present in the Actual Value "+ValueReturned+" miss match"
            ,Status.FAIL);
          //  takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );
                return false;
        }
        
}
	
	/**
	 * returns true if the element actual value equals to blank/null  and adds Log Accordingly 
	 * @author Cognizant
	 * @return boolean
	 */
	public boolean verifyValueNotBlank() throws Exception {
		String stepName="VerifyValueNotBlank";
	        String ValueReturned=getValue().trim();
	        
	        if(ValueReturned.length()>0){
	                report.updateTestLog(stepName,ElementIdentificatoin+"The Expected Value:blank in the UI and Actual Values match"
	                ,Status.PASS);
	                return true;
	        }else{
	              report.updateTestLog(stepName,ElementIdentificatoin+"The Expected Value:blank in the UI and Actual Value:"+ValueReturned+" miss match"
	            ,Status.FAIL);
	          //  takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );
	                return false;
	        }
	        
	}

	/**
	 * returns true if the element actual value equals to expected  and adds Log Accordingly with Cutsom Message
	 * @author Cognizant
	 * @param ExpectedValue
	 * 		  CutsomMessagetoAppendBegining
	 * @return boolean
	 */
public boolean verifyValue(String ExpectedValue,String CutsomMessagetoAppendBegining) throws Exception {
	String stepName="VerifyValue";
        String ValueReturned=getValue().trim();
        
        if(ExpectedValue.trim().equals(ValueReturned)){
                report.updateTestLog(stepName,CutsomMessagetoAppendBegining+" "+ElementIdentificatoin+"The Expected Value: " + ExpectedValue +" and Actual Values match"
                ,Status.PASS);
                return true;
        }else{
        	report.updateTestLog(stepName,CutsomMessagetoAppendBegining+" "+ElementIdentificatoin+"The Expected Value: " + ExpectedValue +" and Actual Value:"+ValueReturned+" miss match"
            ,Status.FAIL);
          //  takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );
                return false;
        }
        
}
	/**
	 * not used
	 * @param ExpectedValue
	 * @return boolean
	 */
	
private boolean assertValue(String ExpectedValue) throws Exception {
	String stepName="assertValue";
        String ValueReturned=getValue().trim();
        
        if(ExpectedValue.trim().equals(ValueReturned)){
                report.updateTestLog(stepName,"The Expected Value: " + ExpectedValue +" and Actual Values match"
                ,Status.PASS);
                return true;
        }else{
                report.updateTestLog(stepName,"The Expected Value: " + ExpectedValue +" and Actual Value:"+ValueReturned+" miss match"
                ,Status.FAIL);
                throw new Exception("The Expected Value: " + ExpectedValue +" and Actual Value:"+ValueReturned+" miss match");
             //   takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );
              //  takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );   throw new Exception("The Expected Value: " + ExpectedValue +" and Actual Value"+ValueReturned+" miss match");
        }
        
}

/**
 * highligts web element if it is found on the page with YELLOW
 * @author Cognizant
 */
public void highlight() throws Exception {
	WebElement element=searchElement();
	//for (int i = 0; i < 2; i++) { 
		Javascript.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "color: yellow; border: 2px solid yellow;"); 
		//Javascript.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, ""); 
	//	} 
	} 

/**
 * returns true if the element actual value equals to expected  and adds Log Accordingly for DROP DOWM web element
 * @author Cognizant
 * @param ValuesCommaSeperated
 * @return boolean
 */

public boolean verifySelectValues(String ValuesCommaSeperated) throws Exception{
	String stepName="verifySelectValues";
	List<String> values = getValues();
	String valuestobeverified[]=ValuesCommaSeperated.split(",");
	List<String> valuesexpected=new ArrayList<String>();
	
	for (String values1 : valuestobeverified) {
		valuesexpected.add(values1);
	}
	valuesexpected.removeAll(values);
	if(valuesexpected.size()>0){
		report.updateTestLog(stepName,ElementIdentificatoin+"The Expected Value: [" + ValuesCommaSeperated +"]"
		,Status.FAIL);
		  report.updateTestLog(stepName,"Actual Values does not contain:"+valuesexpected.toString()+" miss match"
          ,Status.FAIL);
        //  takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );
          return false;
	}else{
		
		report.updateTestLog(stepName,ElementIdentificatoin+"The Expected Value: [" + ValuesCommaSeperated +"]"
		,Status.PASS);
		  report.updateTestLog(stepName,"Actual Values Match"
          ,Status.PASS);
		return true;
	}
}
	
/**
 * uncheck or click if the checkbox is checked
 * @author Cognizant
 */
public void uncheck() throws Exception {
	String stepName="uncheck";
    xpathFieldMapping.toString();
    WebElement element;
    try{ element=searchElement();}catch(Exception e){report.updateTestLog("Run Time Error in "+stepName, e.getMessage(), Status.FAIL); throw new Exception(e.getMessage());}
    System.out.println("Un Check:"+element.getAttribute("checked"));
    try {
           if(element.getAttribute("checked")!=null && element.getAttribute("checked").equalsIgnoreCase("true")){
                  element.click();
           }
           report.updateTestLog(stepName,"Clicked on "+xpathFieldMapping.toString()
           ,Status.PASS);
           xpaths.clear();
           xpathindex.clear();
           xpathFieldMapping.clear();
           
    } catch (Exception e) {
           //e.printStackTrace();
           if (e.getMessage().toLowerCase().contains("cannot")) {
                  Javascript.executeScript("arguments[0].click()", element);
                  xpaths.clear();
                  xpathindex.clear();
                  xpathFieldMapping.clear();
           } else {
                  numberOfTimesCommandRepeat--;
                  if (numberOfTimesCommandRepeat > 0) {
                        Thread.sleep(1000);
                        uncheck();
                  } else {
                        report.updateTestLog(stepName,"could not click "+xpathFieldMapping.toString()
                        ,Status.FAIL);
                        xpaths.clear();
                        xpathindex.clear();
                        xpathFieldMapping.clear();
                      //  takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );   throw new Exception("Failed at:  " + Field);
                  }
           }
    }
}

/**
 * check or click if the checkbox is un checked
 * @author Cognizant
 */

public void check() throws Exception {
	String stepName="check";
    xpathFieldMapping.toString();
    WebElement element;
    try{ element=searchElement();}catch(Exception e){report.updateTestLog("Run Time Error in "+stepName, e.getMessage(), Status.FAIL); throw new Exception(e.getMessage());}
    try {
           if(element.getAttribute("checked")==null || !element.getAttribute("checked").equalsIgnoreCase("checked")){
                  element.click();
           }
           report.updateTestLog(stepName,"Clicked on "+xpathFieldMapping.toString(),Status.PASS);
           xpaths.clear();
           xpathindex.clear();
           xpathFieldMapping.clear();
           
    } catch (Exception e) {
           //e.printStackTrace();
           if (e.getMessage().toLowerCase().contains("cannot")) {
                  Javascript.executeScript("arguments[0].click()", element);
                  xpaths.clear();
                  xpathindex.clear();
                  xpathFieldMapping.clear();
           } else {
                  numberOfTimesCommandRepeat--;
                  if (numberOfTimesCommandRepeat > 0) {
                        Thread.sleep(1000);
                        check();
                  } else {
                        report.updateTestLog(stepName,"could not click "+xpathFieldMapping.toString() ,Status.FAIL);
                        xpaths.clear();
                        xpathindex.clear();
                        xpathFieldMapping.clear();
                       // takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );   throw new Exception("Failed at:  " + Field);
                  }
           }
    }
}

/**
 * refers to the web element in the path
 * @author Cognizant
 * @param partialLinkText
 */

public WebElementMethods linkContains(String partialLinkText) throws Exception {
    String tempXpath=xpaths.get(0);
    tempXpath="("+tempXpath+")//a[contains(text(),'"+partialLinkText+"')]";
    xpaths.clear();
    String fieldIndentification=xpathFieldMapping.get(0);
    xpathFieldMapping.clear();
    return findElementByXpath(tempXpath, fieldIndentification+", Link: "+partialLinkText);
    
}


/**
 * verifies field is required
 * @author Cognizant
 * @return boolean
 */
public boolean verifyIsRequired() throws Exception {
	String stepName="verifyIsRequired";
	String tempXpath=xpaths.get(0);
    tempXpath=tempXpath+"//div[@class='requiredBlock']";
    xpaths.clear();
    String fieldIndentification=xpathFieldMapping.get(0);
    xpathFieldMapping.clear();
    
    if(findElementByXpath(tempXpath, fieldIndentification).isElementPresent()){
            report.updateTestLog(stepName,ElementIdentificatoin+" is a Required Field",Status.PASS);
            return true;
    }else{
    	report.updateTestLog(stepName,ElementIdentificatoin+" is a not Required Field",Status.FAIL);
            return false;
    }
}

}

/**
 * Browser Window Object
 * @author Cognizant
 * @return {@link Window}
 */
public Window window(){
	return new Window();
}

/**
 * Window methods and user friendly commands
 * @author Cognizant 
 */

public class Window{
	
	/**
	 * closes the current window and closes the driver instance NOTE: not used in the wrapper
	 * @author Cognizant
	 * @return void
	 */
	private void quit() {
		String stepName="quit";
		String title;
		try{
			title=driver.getTitle();
		driver.quit();
		System.exit(0);
		report.updateTestLog(stepName,"Closed the Applicaion: "+ title+" successfully"
		,Status.PASS);
		}catch(Exception e){
			report.updateTestLog(stepName,"Failed to Close the Applicaion: "+ driver.getTitle()
			,Status.FAIL);
			try {
				//takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );
			} catch (Exception e1) {
				
			}
		}
	}
	/**
	 * select the window root document, if any frame is switched
	 * @author Cognizant
	 * @return void
	 */

	public void selectDefault() {
		driver.switchTo().defaultContent();
	}
	
	/**
	 * Select frame, which are placed under the window (applies for nested frame by switching to parent frame)
	 * @author Cognizant
	 * @param FrameID
	 *            ID of the frame to be selected
	 */

	public void selectFrame(String FrameID) throws Exception {
		time = 30;
		int i = 0;
		while (i < time) {
			try {
				driver.switchTo().frame(FrameID);
				break;
			} catch (Exception e) {
				Thread.sleep(1000);
				i++;
				if (i == time) {
					//takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );   
					throw new Exception("Could not find frame");
				}
			}
		}
	}

	
	/**
	 * Select frame, which are placed under the window (applies for nested frame by switching to parent frame)
	 * @author Cognizant
	 * @param frameIndex
	 *            Number of the frame to be selected from document based on the
	 *            occurrence
	 */
	public void selectFrame(int frameIndex) throws Exception {
		int i = 0;
		time = 30;
		while (i < time) {
			try {
				driver.switchTo().frame(frameIndex);
				break;
			} catch (Exception e) {
				Thread.sleep(1000);
				i++;
				if (i == time) {
					//takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );   
					throw new Exception("Could not find frame");
				}
			}
		}
	}

	

	/**
	 * change the current window URL
	 * @author Cognizant
	 * @param URL
	 *            URL to be changed
	 */
	public void changeURLto(String URL) {
			driver.navigate().to(URL);
	}
	/**
	 * closes the current window
	 * @author Cognizant
	 */
	public void close() {
		String stepName="close";
		String title;
		try{
			title=driver.getTitle();
		driver.switchTo().defaultContent();
		driver.close();
		report.updateTestLog(stepName,"Closed the Applicaion: "+ title+" successfully"
		,Status.PASS);
		}catch(Exception e){
			report.updateTestLog(stepName,"Failed to Close the Applicaion: "+ driver.getTitle()
			,Status.FAIL);
		}
	}
	/**
	 * get current window opened handle
	 * @author Cognizant
	 * @return String
	 * 
	 */
	public String getWindowHandle() {
		return driver.getWindowHandle();
	}
	
	/**
	 * get all window handles 
	 * @author Cognizant
	 * @return Set<String>
	 * 
	 */
	public Set<String> getWindowHandles() {

		return driver.getWindowHandles();
	}

	
	/**
	 * get page source of current window
	 * @author Cognizant
	 * @return String
	 */

	public String getPageSource() {

		return driver.getPageSource();
	}
	/**
	 * get title of current window
	 * @author Cognizant
	 * @return String
	 */
	public String getTitle() {
		return driver.getTitle();
	}
	/**
	 * Switch window or to work with multiple windows opened by the script
	 * @author Cognizant          
	 * @param windowNo
	 *            Number of the Window to be selected based on the occurrence by
	 *            which opened
	 */
	public void selectWindow(int windowNo) throws Exception {
		String stepName="selectWindow";
		try {

			Thread.sleep(5000);
			Set<String> temp = new HashSet<String>();

			if (temp_windows.size() < driver.getWindowHandles().size()) {
				temp.addAll(driver.getWindowHandles());
				temp.removeAll(temp_windows);
				windows.addAll(temp);
			}

			if (temp_windows.size() > driver.getWindowHandles().size()) {
				temp.addAll(driver.getWindowHandles());
				temp_windows.removeAll(temp);
				windows.removeAll(temp_windows);
			}
			temp_windows.clear();
			temp_windows.addAll(driver.getWindowHandles());
			driver.switchTo().window(windows.get((windowNo - 1)));
			report.updateTestLog(stepName,"Selected window:" +windowNo +" with title"+ driver.getTitle()
			,Status.PASS);
		} catch (Exception e) {
			e.printStackTrace();
			report.updateTestLog(stepName,"Failed to select window:" +windowNo
			,Status.FAIL);
			//takeScreenPrint("Results\\" + folderName + "\\" +"ScreenPrints\\"+ TestCaseName + StartDateAndTime + "\\" + "screenprint" );  
			throw new Exception("Failed At Switching the window");
		}
	}
	
	/**
	 * maximize the current window
	 * @author Cognizant
	 */
	public void maximize() {
		try{
			//driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);
			driver.manage().window().maximize();
		//execute("if(window.screen){window.moveTo(0, 0);window.resizeTo(window.screen.availWidth,window.screen.availHeight);};");
		}catch(Exception e){
			
		}
	}
	
	/**
	 * focus the window 
	 * @author Cognizant
	 */
	public void windowfocus() {
		executeJavaScript("window.focus();");
	}
	
	/**
	 * returns number of windows opened 
	 * @author Cognizant
	 */
public int getNumberOfWindowsOpen() throws Exception{
	waitForComplete();
	return driver.getWindowHandles().size();
}

/**
 * close window by title
 * @author Cognizant
 * @param windowTitle
 */

public void closeWindowByTitle(String windowTitle) throws Exception {
    waitForComplete();
	String currentWindowHandle=driver.getWindowHandle();
	try{
	for ( String windowHandle : driver.getWindowHandles()) {
		driver.switchTo().window(windowHandle);
		if(driver.getTitle().equals(windowTitle)){
			driver.close();
		}/*else{
			driver.switchTo().window(currentWindowHandle);
		}*/
	}
	}catch(Exception e){
	    
	}
	driver.switchTo().window(currentWindowHandle);	
	
}

/**
 * Returns true or false if the window present
 * @author Cognizant
 * @param patialWindowTitle
 * @return boolean
 */


public boolean isWindowByTitlePresent(String patialWindowTitle) throws Exception {
	boolean windowPresent=false;
	String currentWindowHandle=null;
	try{
	currentWindowHandle=driver.getWindowHandle();
	
	for ( String windowHandle : driver.getWindowHandles()) {
		if(currentWindowHandle==null)
			currentWindowHandle=windowHandle;
		driver.switchTo().window(windowHandle);
		if(driver.getTitle().contains(patialWindowTitle)){
			windowPresent=true;
		}
	}
	driver.switchTo().window(currentWindowHandle);
	}catch(Exception e){
	}
	return windowPresent;
}

/**
 * close all windows except title given
 * @author Cognizant
 * @param patialWindowTitle
 */

public void closeAllWindowsExcept(String patialWindowTitle) throws Exception {
	String currentWindowHandle=driver.getWindowHandle();
	for ( String windowHandle : driver.getWindowHandles()) {
		if(!driver.switchTo().window(windowHandle).getTitle().contains(patialWindowTitle)){
			driver.close();
		}else{
			driver.switchTo().window(currentWindowHandle);
		}
	}
	selectWindowByTitle(patialWindowTitle);
}

/**
 * select window by given title
 * @author Cognizant
 * @param patialWindowTitle
 */

public boolean selectWindowByTitle(String patialWindowTitle) {
	String currentWindowHandle=driver.getWindowHandle();
	for ( String windowHandle : driver.getWindowHandles()) {
		if(driver.switchTo().window(windowHandle).getTitle().contains(patialWindowTitle)){
			return true;
		}
	}
	driver.switchTo().window(currentWindowHandle);
	return false;
}

/**
 * close window contains title
 * @author Cognizant
 * @param patialWindowTitle
 */

public void closeWindowContainsTitle(String patialWindowTitle) throws Exception {
    waitForComplete();
	String currentWindowHandle = driver.getWindowHandle();
	try{
	for (String windowHandle : driver.getWindowHandles()) {
	    driver.switchTo().window(windowHandle);
	    if (driver.getTitle().contains(patialWindowTitle)) {
		driver.close();
	    }
	}
	}catch(Exception e){
	}
	driver.switchTo().window(currentWindowHandle);
 
}

/**
 * close windows except the current window
 * @author Cognizant
 */

public void closeAllPopupBrowsersExceptCurrent() {
	String currentWindowHandle=driver.getWindowHandle();
	for ( String windowHandle : driver.getWindowHandles()) {
		if(!currentWindowHandle.equals(windowHandle)){
		driver.switchTo().window(windowHandle);
		driver.close();
		driver.switchTo().window(currentWindowHandle);
	}
	}
}




/**
 * get current window URL
 * @author Cognizant
 * @returns String
 */
public String getCurrentUrl() {

	return driver.getCurrentUrl();
}
}




// SFDC Create Reporsitory functions
/**
 * creates page object repository in pages folder of CRAFT by analyzing current open standard page
 * @author Cognizant
 * @param screen
 * 			name to be given for page object repository
 */
public void createRepositoryFromRecord(String screen)
		throws Exception {
	Thread.sleep(10000);
	JavascriptExecutor js = (JavascriptExecutor) driver;
	waitForComplete();
	ArrayList<String> fields = new ArrayList<String>();
	ArrayList<String> buttons = new ArrayList<String>();
	ArrayList<String> sections = new ArrayList<String>();
	ArrayList<String> relatedList = new ArrayList<String>();
	String screen1 = "";
	String finals = "";
	Hashtable<String, Integer> table = new Hashtable<String, Integer>();
	screen1 = screen.replace(" ", "") + "Screen";
	finals = "package pages;\n"
			+ "import SFDC.SeleniumWrapper;\n"
			+ "import supportlibraries.ScriptHelper;\n"
			+ "public class "
			+ screen1 + " extends SeleniumWrapper {\n" 
			+ "private String fieldName=\"\";\n"
			+ "private String finalXpath=\"\";\n"
			+ "private String section=\"\";\n"
			+ "public "+screen1+"(ScriptHelper scriptHelper) {\n"
			+ "super(scriptHelper);\n"
			+ "	this.scriptHelper=scriptHelper;\n"
			+ "	}\n";

	int numberofbutton = 0, Numberoffields = 0;
	buttons.clear();
	table.clear();
	fields.clear();
	System.out.println("Creating Repository for " + screen);
	// screen=screen.replace(" ", "");
	System.out.println("Read only Level Fields");
	Numberoffields = driver.findElements(
			By.xpath("//div[@id='ep']//td[contains(@class,'label')]"))
			.size();
	for (int ele = 1; ele <= Numberoffields; ele++) {
		WebElement element = driver.findElement(By
				.xpath("(//div[@id='ep']//td[contains(@class,'label')])["
						+ ele + "]"));
		String m = element.getText();
		if (!m.trim().equals("")) {
			String fieldName = m;
			fields.add(fieldName);
		}
	}
	
	Numberoffields = driver.findElements(
			By.xpath("//div[@id='ep']//label"))
			.size();
	for (int ele = 1; ele <= Numberoffields; ele++) {
		WebElement element = driver.findElement(By
				.xpath("(//div[@id='ep']//label)["
						+ ele + "]"));
		String m = element.getText();
		if (!m.trim().equals("")) {
			String fieldName = m;
			if(!fields.contains(fieldName))
			fields.add(fieldName);
		}
	}
	
	

	System.out.println("Details page Fields");
	for (int ele = 0; ele < fields.size(); ele++) {
		String element = fields.get(ele);
		String m = element;
		if (!m.trim().equals("")) {
			int index = 0;
			try {
				int mmm;
				mmm = table.get(m).intValue();
				table.put(m, mmm + 1);
				index = mmm + 1;
			} catch (Exception e) {
				index = 0;
				table.put(m, index);
			}
			String temreturn = xpaths(m,true,false,finals);
			if (!finals.contains(temreturn))
				finals = finals + temreturn;
		}
		System.out.println(element);

	}

	buttons.clear();
	System.out.println("Buttons at read:");
	buttons.add("New");
	buttons.add("Go!");
	buttons.add("Reject");
	buttons.add("Approve");
	Numberoffields = driver.findElements(
			By.xpath("//input[contains(@class,'btn')]")).size();
	for (int ele = 1; ele <= Numberoffields; ele++) {
		WebElement element = driver.findElement(By
				.xpath("(//input[contains(@class,'btn')])[" + ele + "]"));
		String m = element.getAttribute("value").trim();
		if (!buttons.contains(m)) {
			buttons.add(m);
		}
	}

	System.out.println("Sections");
	Numberoffields = driver.findElements(
					By.xpath("//div[@id='ep']//*[not(contains(@id,'Related')) and ((local-name()='h3') or (local-name()='h2'))]"))
			.size();
	for (int ele = 1; ele <= Numberoffields; ele++) {
		WebElement element = driver.findElement(By
						.xpath("(//div[@id='ep']//*[not(contains(@id,'Related')) and ((local-name()='h3') or (local-name()='h2'))])["
								+ ele + "]"));
		String m = element.getText();
		if (!m.trim().equals("")) {
			String fieldName = m;
			sections.add(fieldName);
		}
	}

	System.out.println("Related Lists");
	Numberoffields = driver.findElements(
			By.xpath("//h3[contains(@id,'_title')]")).size();
	for (int ele = 1; ele <= Numberoffields; ele++) {
		WebElement element = driver.findElement(By
				.xpath("(//h3[contains(@id,'_title')])[" + ele + "]"));
		String m = element.getText();
		if (!m.trim().equals("")) {
			String fieldName = m;
			relatedList.add(fieldName);
			System.out.println(m);
		}
	}

	for (int RL = 0; RL < relatedList.size(); RL++) {

		String RLName = getValidMethodName(relatedList.get(RL));
		String ret = "\n" + "return new " + RLName + "RelatedListfields(\""+RLName+"\")";
		String met = "\n \n public " + RLName
				+ "RelatedListfields relatedList_" + RLName
				+ "RelatedListfields() throws Exception{\n";
		met = met + ret + ";\n}";
		finals = finals + met;
		System.out.println(RLName);
		String relatedListXpath="(//h3[contains(text(),\""+relatedList.get(RL)+"\") and local-name()!='option'])[1]/ancestor-or-self::div[1]/following-sibling::div[1]";
		finals = finals + "\n public class " + RLName
				+ "RelatedListfields{ \n"
				+ "String relatedListXpath=\"\";\n"
				+ "String RLName=\"\";"
				+ "public " + RLName + "RelatedListfields(String RelatedListSectionName){\n"
						+ "relatedListXpath=\"(//h3[contains(text(),\\\""+relatedList.get(RL)+"\\\") and local-name()!='option'])[1]/ancestor-or-self::div[1]/following-sibling::div[1]\";\n"
								+ "RLName=\"Related List: \"+RelatedListSectionName;\n"
				+ "}\n"
				+ ""
				+ "";
		Numberoffields = driver.findElements(
						By.xpath("("+relatedListXpath+"//tr[contains(@class,'header')])[1]/*[starts-with(local-name(),'t') and @class!='noRowsHeader']"))
				.size();
		for (int RLIndex = 1; RLIndex <= Numberoffields; RLIndex++) {

			String fieldName = "";

			String element1 = driver.findElement(
							By.xpath("(("+relatedListXpath+"//tr[contains(@class,'header')])[1]/*[starts-with(local-name(),'t')])["
									+ RLIndex + "]")).getText();

			ret = "";
			String xx = element1;

			fieldName = getValidMethodName(xx);
			String xpath = "((\"+relatedListXpath+\"//tr[contains(@class,'data')])[\"+(rowIndex+1)+\"]/*[starts-with(local-name(),'t')])["
					+ RLIndex + "]";
			String tempxpath = "(("+relatedListXpath+"//tr[contains(@class,'data')])[1]/*[starts-with(local-name(),'t')])["
					+ RLIndex + "]";

			String fieldIdentfication;
			if (driver.findElements(
					By.xpath(tempxpath + "//input[@type='text']")).size() > 0) {
				fieldIdentfication = ",Text Box: " + xx.replace("*", "");
				xpath = xpath + "//input[@type='text']";
				fieldName = fieldName + "Textbox";
			} else if (driver.findElements(
					By.xpath(tempxpath + "//input[@type='radio']")).size() > 0) {
				fieldIdentfication = ",Radio Button: " + xx.replace("*", "");
				xpath = xpath + "//input[@type='radio']";
				fieldName = fieldName + "Radio";
			} else if (driver.findElements(
					By.xpath(tempxpath + "//input[@type='checkbox']"))
					.size() > 0) {
				fieldIdentfication = ",Check Box: " + xx.replace("*", "");
				xpath = xpath + "//input[@type='checkbox']";
				fieldName = fieldName + "Checkbox";
			} else if (driver.findElements(By.xpath(tempxpath + "//select"))
					.size() > 0) {
				xpath = xpath + "//select";
				fieldName = fieldName + "DropDown";
				fieldIdentfication = ",DropDown: " + xx.replace("*", "");
			} else if (driver.findElements(By.xpath(tempxpath + "//textarea"))
					.size() > 0) {
				xpath = xpath + "//textarea";
				fieldName = fieldName + "TextArea";
				fieldIdentfication = ",TextArea: " + xx.replace("*", "");
			} else if (driver.findElements(By.xpath(tempxpath + "//img")).size() > 0) {
				xpath = xpath + "//img";
				fieldName = fieldName + "Image";
				fieldIdentfication = ",Image: " + xx.replace("*", "");
			} else if (driver.findElements(By.xpath(tempxpath + "//textarea"))
					.size() > 0) {
				xpath = xpath + "//textarea";
				fieldName = fieldName + "TextArea";
				fieldIdentfication = ",TextArea: " + xx.replace("*", "");
			} else if (driver.findElements(By.xpath(tempxpath + "//a")).size() > 0) {
				xpath = xpath + "//a";
				fieldName = fieldName + "Link";
				fieldIdentfication = ",Link: " + xx.replace("*", "");
			} else {
				fieldIdentfication = "Text: " + xx.replace("*", "");
				fieldName = fieldName + "text";
				fieldIdentfication = ",text: " + xx.replace("*", "");
			}

			// String
			// Xpath=tempXpath+"/ancestor-or-self::*[starts-with(local-name(),'t')][1]";
			// int cellindex=Integer.parseInt(driver.findElement(By.xpath(Xpath,
			// "sectionName, +\""+xx.replace("*",
			// "")+"\"").getAttributeValue("cellIndex"));;
			// String ret = "return driver.findElement(By.xpath(\""+ tempXpath +
			// "\",\""+fieldIdentfication+"\")";
			// String nav = "";
			met = "";
			// String element = null;
			ret = "RLName=RLName+\"" + fieldIdentfication
					+ "\";\n return findElementByXpath(\"" + xpath
					+ "\",RLName)";

			met = "\n \n public WebElementMethods " + fieldName
					+ "(int rowIndex) throws Exception{\n";
			met = met + ret + ";\n}";
			finals = finals + met;
			System.out.println(xx);
			// }

		}

		finals = finals
				+ "\npublic  WebElementMethods  showMoreLink() throws Exception{\n"
				+ "RLName+=\",showmore �\";\n return findElementByXpath(\"\"+relatedListXpath+\"//*[contains(text(),\\\"more �\\\")]\",RLName);\n"
				+ "}\n"
				+ "\npublic  WebElementMethods goToListLink() throws Exception{\n"
				+ "RLName+=\",Go to list\";\n return findElementByXpath(\"\"+relatedListXpath+\"//*[contains(text(),\\\"Go to list\\\")]\",RLName);\n"
				+ "}\n"
				+ "\npublic  WebElementMethods fieldHasText(String text) throws Exception{\n"
				+ "RLName+=\",Link/Text: \"+text;\n return findElementByXpath(\"\"+relatedListXpath+\"//*[contains(text(),\\\"\"+text+\"\\\")]\",RLName);\n"
				+ "}\n"
				+ "\npublic  WebElementMethods Norecordstodisplaytext() throws Exception{\n"
				+ "RLName+=\",No records to display\";\n return findElementByXpath(\"\"+relatedListXpath+\"//*[contains(text(),\\\"No records to display\\\")]\",RLName);\n"
				+ "}\n";

		finals = finals + "}\n";
	}

	if (driver.findElements(
			By.xpath("(//*[(normalize-space(@value)='Edit') and contains(@class,'btn')])[1]"))
			.size() > 0) {
		numberofbutton = driver.findElements(
				By.xpath("//input[contains(@class,'btn')]")).size();
		for (int ele = 1; ele <= numberofbutton; ele++) {
			WebElement element = driver.findElement(By
							.xpath("(//input[contains(@class,'btn')])["
									+ ele + "]"));
			String m = element.getAttribute("value").trim();

			if (!buttons.contains(m)) {
				buttons.add(m);
			}
			//
		}
		driver.findElement(
				By.xpath("(//*[(normalize-space(@value)='Edit') and contains(@class,'btn')])[1]"))
				.click();
		try {
			while (!js.executeScript("return document.readtState;")
					.toString().toLowerCase().equals("complete")) {
				Thread.sleep(1000);
			}
		} catch (Exception e) {
			Thread.sleep(1000);
		}
		int numberofButtons = driver.findElements(
				By.xpath("//input[contains(@class,'btn')]")).size();
		for (int ele = 1; ele <= numberofButtons; ele++) {
			WebElement element = driver.findElement(By
							.xpath("(//input[contains(@class,'btn')])["
									+ ele + "]"));
			String m = element.getAttribute("value").trim();

			if (!buttons.contains(m)) {
				buttons.add(m);
			}
			//
		}

		// int
		// count=sfdc.getWebElement().getDriver().findElements(By.tagName("label")).size();
		System.out.println("Fields for Object as Follows:\n");
		Numberoffields = driver.findElements(
				By.xpath("//form//label[text()!='' and (local-name()='label')]")).size();
		System.out.println("Number for Fields: " + Numberoffields);

		for (int ele = 1; ele <= Numberoffields; ele++) {

			WebElement element = driver.findElement(By
					.xpath("(//form//label[text()!='' and (local-name()='label')])[" + ele + "]"));
			String m = element.getText();
			if (!m.trim().equals("")) {

				int index = 0;
				try {
					int mmm;
					mmm = table.get(m).intValue();
					table.put(m, mmm + 1);
					index = mmm + 1;
				} catch (Exception e) {
					index = 0;
					table.put(m, index);
				}
				String temreturn = xpaths(m,false,fields.contains(m),finals);
				if (!finals.contains(temreturn))
					finals = finals + temreturn;
				System.out.println(m);
			}
		}
		Numberoffields = driver.findElements(
						By.xpath("//form//*[text()!='' and contains(@class,'labelCol')]"))
				.size();
		System.out.println("Number for Fields: " + Numberoffields);

		for (int ele = 1; ele <= Numberoffields; ele++) {
			WebElement element = driver.findElement(By
							.xpath("(//form//*[text()!='' and contains(@class,'labelCol')])["
									+ ele + "]"));
			String m = element.getText();
			if (!m.trim().equals("")) {
				int index = 0;
				try {
					int mmm;
					mmm = table.get(m).intValue();
					table.put(m, mmm + 1);
					index = mmm + 1;
				} catch (Exception e) {
					index = 0;
					table.put(m, index);
				}
				String temreturn = xpaths(m,false,fields.contains(m),finals);
				if (!finals.contains(temreturn))
					finals = finals + temreturn;

				System.out.println(m);
			}
		}
		String fieldName;
		System.out.println("Sections at edit level");
		Numberoffields = driver.findElements(
						By.xpath("//div[@id='ep']//*[not(contains(@id,'Related')) and ((local-name()='h3') or (local-name()='h2'))]"))
				.size();
		for (int ele = 1; ele <= Numberoffields; ele++) {
			WebElement element = driver.findElement(By
							.xpath("(//div[@id='ep']//*[not(contains(@id,'Related')) and ((local-name()='h3') or (local-name()='h2'))])["
									+ ele + "]"));
			String m = element.getText();
			if (!m.trim().equals("")) {
				fieldName = m;
				if(!sections.contains(fieldName))
				sections.add(fieldName);
			}
		}

	}

	finals = finals
			+ "\npublic  WebElementMethods element() throws Exception{\n"
			+ "return findElementByXpath(finalXpath,\"\");\n" + "}\n";

	System.out.println("buttons are:");
	String fieldName;
	for (int ele = 0; ele < buttons.size(); ele++) {
		String ret = "";
		String m = buttons.get(ele);
		System.out.println(m);
		// if(sfdc.getWebElement().getDriver().findElement(By.xpath("//input[contains(@class,'btn')]")).getAttribute("value").trim().equals(m)&&i>0)
		// break;
		// i++;
		/*fieldName = m.replace("+", "").replace("&", "").replace("?", "")
				.replace(":", "").replace("]", "").replace("[", "")
				.replace("-", "").replace(" ", "").replace("*", "")
				.replace("/", "").replace("'", "").replace("!", "")
				.replace("&", "");*/
		
		
		
		 fieldName = getValidMethodName(m);
		
		ret = "return findElementByXpath(\"(//*[(normalize-space(@value)='"
				+ m.replace("*", "")
				+ "') and contains(@class,'btn')])[1]\",\"Button:"+m.replace("*", "")+"\");";
		String met = "\n \n public  WebElementMethods " + fieldName
				+ "Button() throws Exception{\n";
		met = met + ret + "\n}";
		finals = finals + met;

	}

	
	for (int ele = 0; ele < sections.size(); ele++) {
		String element = sections.get(ele);
		String ret = "";
		String m = element;
		if (!m.trim().equals("")) {
			int index = 0;
			try {
				int mmm;
				mmm = table.get(m).intValue();
				table.put(m, mmm + 1);
				index = mmm + 1;
			} catch (Exception e) {
				index = 0;
				table.put(m, index);
			}
			fieldName = getValidMethodName(m);
			if (index == 0)
				ret = "finalXpath=\"//*[contains(local-name(),'h') and contains(text(),\\\""
						+ m.replace("*", "")
						+ "\\\") and local-name()!='option']/ancestor::div[1]/following-sibling::div[1]\";";
			else {
				ret = "finalXpath=\"//*[contains(local-name(),'h') and contains(text(),\\\""
						+ m.replace("*", "")
						+ "\\\") and local-name()!='option']/ancestor::div[1]/following-sibling::div[1]\";";
				fieldName = fieldName + index;
			}
			String nav = "";
			ret = ret + "\n" + "return this;";
			String met = "\n \n public  " + screen1 + " section_"
					+ fieldName + "() throws Exception{\n"
							+ "section=\""+m+"\";\n";
			met = met + ret + nav + "\n}";
			finals = finals + met;
			System.out.println(m);
		}
	}

	finals = finals + "\n";
	File file = new File("pages\\" + screen1 + ".java");
	file.createNewFile();
	BufferedWriter wr = new BufferedWriter(new FileWriter(file));
	wr.write(finals + "\n}");
	wr.close();
	System.out.println("Successfully created Repository");
}

private String xpaths(String m,boolean isDetailsPage,boolean createTextMethod,String finalObjectRepositoryFileContent) throws Exception {
	
	String returnMethods="";
	boolean found=false;
	String fieldName="";
	String fieldMethodName =getValidMethodName(m);

	String nav = "";

	String fieldIdentfication = "";

	String tempxpath = "(//*[text()=\""
			+ m.replace("*", "").trim() + "\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]";
	
	/*String tagname=driver.findElement(By.xpath("(//*[normalize-space(text())=normalize-space(\""
			+ m.replace("*", "") + "\") and local-name()!='option'])[1]")).getTagName();
	*/
	/*tempxpath = "(//*[text()=\""
			+ m.replace("*", "") + "\" and local-name()!='option' and ])[1]";*/
	
	String xpath = "(\"+finalXpath+\"//*[text()=\\\""
			+ m.replace("*", "").trim() + "\\\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]";
	String temObjectRepositoryXpath=xpath;
	nav = "/ancestor-or-self::*[starts-with(local-name(),'t')][1]";
	if (driver.findElements(
			By.xpath(tempxpath + nav + "//input[@type!='hidden']")).size() > 0) {
		if (driver.findElements(
				By.xpath(tempxpath + nav + "//input[@type='radio']")).size() > 0) {
			fieldIdentfication = "Radio Button: " + m.replace("*", "").trim();
			xpath = temObjectRepositoryXpath + nav + "//input[@type='radio']";
			fieldName = fieldMethodName + "Radio";
		} else if (driver.findElements(
				By.xpath(tempxpath + nav + "//input[@type='checkbox']")).size() > 0) {
			fieldIdentfication = "Check Box: " + m.replace("*", "").trim();
			xpath = temObjectRepositoryXpath + nav + "//input[@type='checkbox']";
			fieldName = fieldMethodName + "Checkbox";
		}else if (driver.findElements(
				By.xpath(tempxpath + nav + "//input[@type='text']")).size() > 0) {
			fieldIdentfication = "Text Box: " + m.replace("*", "").trim();
			xpath = temObjectRepositoryXpath + nav + "//input[@type='text']";
			fieldName = fieldMethodName + "Textbox";
		} 
		returnMethods=getMethodName(xpath, fieldName, fieldIdentfication);
	} else {
		nav = "/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
		if (driver.findElements(
				By.xpath(tempxpath + nav + "//input[@type='text']")).size() > 0) {
			fieldIdentfication = "Text Box: " + m.replace("*", "").trim();
			xpath = temObjectRepositoryXpath + nav + "//input[@type='text']";
			fieldName = fieldMethodName + "Textbox";
			String returnMethod=getMethodName(xpath, fieldName, fieldIdentfication);
			returnMethods+=finalObjectRepositoryFileContent.contains(fieldName)?"":returnMethod;
			found=true;fieldName="";
		}  if (driver.findElements(
				By.xpath(tempxpath + nav + "//input[@type='radio']"))
				.size() > 0) {
			fieldIdentfication = "Radio Button: " + m.replace("*", "").trim();
			xpath = temObjectRepositoryXpath + nav + "//input[@type='radio']";
			fieldName = fieldMethodName + "Radio";
			String returnMethod=getMethodName(xpath, fieldName, fieldIdentfication); 
			returnMethods+=finalObjectRepositoryFileContent.contains(fieldName)?"":returnMethod;
			found=true;fieldName="";
		}  if (driver.findElements(
				By.xpath(tempxpath + nav + "//input[@type='checkbox']"))
				.size() > 0) {
			fieldIdentfication = "Check Box: " + m.replace("*", "").trim();
			xpath = temObjectRepositoryXpath + nav + "//input[@type='checkbox']";
			fieldName = fieldMethodName + "Checkbox";
			String returnMethod=getMethodName(xpath, fieldName, fieldIdentfication); 
			returnMethods+=finalObjectRepositoryFileContent.contains(fieldName)?"":returnMethod;
			found=true;fieldName="";
		}  if (driver.findElements(By.xpath(tempxpath + nav + "//select"))
				.size() > 0) {
			String multiSelect = driver.findElement(
					By.xpath(tempxpath + nav + "//select")).getAttribute(
					"multiple");
			if (multiSelect == null || multiSelect.equals("")) {
				xpath = temObjectRepositoryXpath + nav + "//select";
				fieldName = fieldMethodName + "DropDown";
				fieldIdentfication = "DropDown: " + m.replace("*", "").trim();
				String returnMethod=getMethodName(xpath, fieldName, fieldIdentfication); 
				returnMethods+=finalObjectRepositoryFileContent.contains(fieldName)?"":returnMethod;
				found=true;fieldName="";
			} else {
				xpath = temObjectRepositoryXpath + nav;
				fieldName = fieldMethodName + "MultiselectDropDown";
				fieldIdentfication = "Multi select DropDown: "
						+ m.replace("*", "").trim();
				String returnMethod=getMethodName(xpath, fieldName, fieldIdentfication); 
				returnMethods+=finalObjectRepositoryFileContent.contains(fieldName)?"":returnMethod;
				found=true;fieldName="";
			}
		}  if (driver.findElements(By.xpath(tempxpath + nav + "//textarea"))
				.size() > 0) {
			xpath = temObjectRepositoryXpath + nav + "//textarea";
			fieldName = fieldMethodName + "TextArea";
			fieldIdentfication = "TextArea: " + m.replace("*", "").trim();
			String returnMethod=getMethodName(xpath, fieldName, fieldIdentfication); 
			returnMethods+=finalObjectRepositoryFileContent.contains(fieldName)?"":returnMethod;
			found=true;fieldName="";
		}  if (driver.findElements(By.xpath(tempxpath + nav + "//a[text()!='']")).size() > 0) {
			xpath = temObjectRepositoryXpath + nav + "//a[text()!='']";
			fieldName = fieldMethodName + "Link";
			fieldIdentfication = "Link: " + m.replace("*", "").trim();
			String returnMethod=getMethodName(xpath, fieldName, fieldIdentfication); 
			returnMethods+=finalObjectRepositoryFileContent.contains(fieldName)?"":returnMethod;
			fieldName="";
		}  if (driver.findElements(By.xpath(tempxpath + nav + "//img"))
				.size() > 0) {
			xpath = temObjectRepositoryXpath + nav + "//img";
			fieldName = fieldMethodName + "Image";
			fieldIdentfication = "Image: " + m.replace("*", "").trim();
			String returnMethod=getMethodName(xpath, fieldName, fieldIdentfication); 
			returnMethods+=finalObjectRepositoryFileContent.contains(fieldName)?"":returnMethod;
			fieldName="";
		}  		
			fieldIdentfication = "Text: " + m.replace("*", "").trim();
			xpath = temObjectRepositoryXpath + nav;
			fieldName = fieldMethodName + "text";
			fieldIdentfication = "text: " + m.replace("*", "").trim();
			String returnMethod=getMethodName(xpath, fieldName, fieldIdentfication); 
			returnMethods+=finalObjectRepositoryFileContent.contains(fieldName)?"":returnMethod;
	
	}

	return returnMethods;
}

String getMethodName(String xpath,String fieldName,String fieldIdentfication){
	
	String ret = "String tempxpath=\"" + xpath + "\";\n"
			+ "finalXpath=\"\";\n" + "if(!section.equals(\"\"))\n"
			+ "fieldName=\"Section: \"+section+\"," + fieldIdentfication
			+ "\";\n" + "else\n" + "fieldName=\"" + fieldIdentfication
			+ "\";\n" + "section=\"\";\n"
			+ "return findElementByXpath(tempxpath, fieldName)";

	String met = "\n \n public  WebElementMethods " + fieldName
			+ "() throws Exception{\n";
	
	return met = met + ret + ";\n}";
	
}

String getValidMethodName(String fieldName){
	String fieldMethodName = fieldName.replace("+", "").replace("&", "").replace("?", "")
			.replace(":", "").replace("]", "").replace("[", "")
			.replace("-", "").replace(" ", "").replace("*", "")
			.replace("/", "").replace("'", "").replace("(", "")
			.replace(">", "").replace("<", "").replace("%", "")
			.replace(")", "").replace(",", "").replace("#", "")
			.replace("$", "").replace(".", "").replace("!", "");
	if (fieldMethodName.startsWith("0") || fieldMethodName.startsWith("1")
			|| fieldMethodName.startsWith("2") || fieldMethodName.startsWith("3")
			|| fieldMethodName.startsWith("4") || fieldMethodName.startsWith("5")
			|| fieldMethodName.startsWith("6") || fieldMethodName.startsWith("7")
			|| fieldMethodName.startsWith("8") || fieldMethodName.startsWith("9")) {
		fieldMethodName = fieldMethodName.substring(1);
	}
	return fieldMethodName.trim();
}


// SFDC OOTB functions

/**
 * enter the value and clicks on the search button
 * @author Cognizant
 * @param valueToSearch
 * 		  Value to be searched in the search global in the SFDC application	
 */
public void searchGlobal(String valueToSearch) throws Exception {
	findElementByXpath("//input[contains(@title,'Search') or contains(@id,'Search') or contains(@name,'Search')]","Text Box: Global Serach").type(valueToSearch+Keys.ENTER);
	for(int i=0;i<5;i++){
		if(findElementByXpath("//*[text()='No matches found']","No Mathched foud in Search").isElementPresent()){
			Thread.sleep(3000);
			findElementByXpath("(//*[(normalize-space(@value)='Search Again') and contains(@class,'btn')])[1]","Button:Search Again").click();
		}
	}
	
	if(findElementByXpath("//img[@title='Close' and @class='dialogClose']","Close X Button").isElementPresent()){
		findElementByXpath("//img[@title='Close' and @class='dialogClose']","Close X Button").click();
	    }

}

/**
 * Refers to specific section of the search result page
 * @author Cognizant
 * @param sectionName
 * @return {@link WebElementMethods}
 */

public  WebElementMethods searchResults(String sectionName) throws Exception {
	/*if(formfield("GLOBALFOUNDRYVIEW").element().isElementPresent()){
		sectionName=sectionName.substring(0,sectionName.length()-1);
	}*/
    
    try{
    	if(findElementByXpath("//img[@title='Close' and @class='dialogClose']","Close X Button").isElementPresent()){
    		findElementByXpath("//img[@title='Close' and @class='dialogClose']","Close X Button").click();
	    }
    }catch(Exception e){
	
    }
    xpath="";
	xpath = "//*[(contains(normalize-space(text()),'"+ sectionName + "')) and (local-name()='h3' or (local-name()='span' and contains(@class,'searchFirstCell')))]/ancestor-or-self::*[starts-with(local-name(),'div')][1]/following-sibling::*[1]";
	return findElementByXpath(xpath, "Search Results: "+sectionName);
}

/**
 * open the provided URL in CRAFT instantiated browser
 * @author Cognizant
 * @param URL
 *            URL to be opened
 */

public void openURL(String URL) {
	try {
		Javascript = ((JavascriptExecutor) driver);
		driver.get(URL);
		driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		Thread.sleep(5000);
		temp_windows = new HashSet<String>();
		temp_windows.add(driver.getWindowHandle());
		windows = new ArrayList<String>();
		windows.addAll(temp_windows);
		driver.manage().window().maximize();
	} catch (Exception e) {
		e.printStackTrace();
	}

}

/**
 * Select Tab from Tabs available
 * @author Cognizant
 * @param tabName
 *            tabName to be opened
 * @throws Exception 
 */

public void selectTab(String tabName) throws Exception{
	findElementByXpath("//a[text()='"+tabName+"' and contains(@title,'Tab')]", "Select Tab: "+tabName).click();
}

/**
 * Select Tab by navigating to All Tabs
 * @author Cognizant
 * @param tabName
 *            tabName to be selected from All Tabs options
 * @throws Exception 
 */

public void selectTabByNavigatingToAllTabs(String tabName) throws Exception{
	findElementByXpath("//img[contains(@title,'All Tabs')]", "Select: ALL Tabs").click();
	findElementByXpath("//a[contains(@class,'listRelatedObject') and text()='"+tabName+"']", "Select Tab: "+tabName).click();
}

/**
 * Select Tab by navigating to All Tabs
 * @author Cognizant
 * @param tabName
 *            tabName to be selected from All Tabs options
 *        index
 *        	  index starts with 1, if there are multiple tabs with same name in All tabs options
 * @throws Exception 
 */

public void selectTabByNavigatingToAllTabs(String tabName,String index) throws Exception{
	findElementByXpath("//img[contains(@title,'All Tabs')]", "Select: ALL Tabs").click();
	findElementByXpath("(//a[contains(@class,'listRelatedObject') and text()='"+tabName+"'])["+index+"]", "Select Tab: "+tabName).click();
}


}
