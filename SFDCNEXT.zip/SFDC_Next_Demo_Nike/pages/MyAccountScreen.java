package pages;
import SFDC.SeleniumWrapper;
import supportlibraries.ScriptHelper;
public class MyAccountScreen extends SeleniumWrapper {
private String fieldName="";
private String finalXpath="";
private String section="";
public MyAccountScreen(ScriptHelper scriptHelper) {
super(scriptHelper);
	this.scriptHelper=scriptHelper;
	}

 
 public  WebElementMethods MyAccountNametext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"My Account Name\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: My Account Name";
else
fieldName="text: My Account Name";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods OwnerLink() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Owner\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//a[text()!='']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Link: Owner";
else
fieldName="Link: Owner";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods OwnerImage() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Owner\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//img";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Image: Owner";
else
fieldName="Image: Owner";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods Ownertext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Owner\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Owner";
else
fieldName="text: Owner";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods ParentNametext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Parent Name\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Parent Name";
else
fieldName="text: Parent Name";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods ShortNametext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Short Name\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Short Name";
else
fieldName="text: Short Name";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods Organisationtext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Organisation\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Organisation";
else
fieldName="text: Organisation";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods CreatedByLink() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Created By\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//a[text()!='']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Link: Created By";
else
fieldName="Link: Created By";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods CreatedBytext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Created By\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Created By";
else
fieldName="text: Created By";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods LastModifiedByLink() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Last Modified By\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//a[text()!='']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Link: Last Modified By";
else
fieldName="Link: Last Modified By";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods LastModifiedBytext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Last Modified By\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Last Modified By";
else
fieldName="text: Last Modified By";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public SurveyAssignmentRelatedListfields relatedList_SurveyAssignmentRelatedListfields() throws Exception{

return new SurveyAssignmentRelatedListfields("SurveyAssignment");
}
 public class SurveyAssignmentRelatedListfields{ 
String relatedListXpath="";
String RLName="";public SurveyAssignmentRelatedListfields(String RelatedListSectionName){
relatedListXpath="(//h3[contains(text(),\"Survey Assignment\") and local-name()!='option'])[1]/ancestor-or-self::div[1]/following-sibling::div[1]";
RLName="Related List: "+RelatedListSectionName;
}

 
 public WebElementMethods ActionLink(int rowIndex) throws Exception{
RLName=RLName+",Link: Action";
 return findElementByXpath("(("+relatedListXpath+"//tr[contains(@class,'data')])["+(rowIndex+1)+"]/*[starts-with(local-name(),'t')])[1]//a",RLName);
}
 
 public WebElementMethods SurveyNameLink(int rowIndex) throws Exception{
RLName=RLName+",Link: Survey Name";
 return findElementByXpath("(("+relatedListXpath+"//tr[contains(@class,'data')])["+(rowIndex+1)+"]/*[starts-with(local-name(),'t')])[2]//a",RLName);
}
public  WebElementMethods  showMoreLink() throws Exception{
RLName+=",showmore �";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"more �\")]",RLName);
}

public  WebElementMethods goToListLink() throws Exception{
RLName+=",Go to list";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"Go to list\")]",RLName);
}

public  WebElementMethods fieldHasText(String text) throws Exception{
RLName+=",Link/Text: "+text;
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\""+text+"\")]",RLName);
}

public  WebElementMethods Norecordstodisplaytext() throws Exception{
RLName+=",No records to display";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"No records to display\")]",RLName);
}
}

 
 public  WebElementMethods MyAccountNameTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"My Account Name\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: My Account Name";
else
fieldName="Text Box: My Account Name";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods ParentNameTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Parent Name\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Parent Name";
else
fieldName="Text Box: Parent Name";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods ShortNameTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Short Name\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Short Name";
else
fieldName="Text Box: Short Name";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods OrganisationTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Organisation\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Organisation";
else
fieldName="Text Box: Organisation";
section="";
return findElementByXpath(tempxpath, fieldName);
}
public  WebElementMethods element() throws Exception{
return findElementByXpath(finalXpath,"");
}

 
 public  WebElementMethods NewButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='New') and contains(@class,'btn')])[1]","Button:New");
}
 
 public  WebElementMethods GoButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Go!') and contains(@class,'btn')])[1]","Button:Go!");
}
 
 public  WebElementMethods RejectButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Reject') and contains(@class,'btn')])[1]","Button:Reject");
}
 
 public  WebElementMethods ApproveButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Approve') and contains(@class,'btn')])[1]","Button:Approve");
}
 
 public  WebElementMethods SaveButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Save') and contains(@class,'btn')])[1]","Button:Save");
}
 
 public  WebElementMethods CancelButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Cancel') and contains(@class,'btn')])[1]","Button:Cancel");
}
 
 public  WebElementMethods EditButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Edit') and contains(@class,'btn')])[1]","Button:Edit");
}
 
 public  WebElementMethods DeleteButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Delete') and contains(@class,'btn')])[1]","Button:Delete");
}
 
 public  WebElementMethods CloneButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Clone') and contains(@class,'btn')])[1]","Button:Clone");
}
 
 public  WebElementMethods NewSurveyButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='New Survey') and contains(@class,'btn')])[1]","Button:New Survey");
}
 
 public  WebElementMethods SaveNewButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Save & New') and contains(@class,'btn')])[1]","Button:Save & New");
}
 
 public  MyAccountScreen section_MyAccountDetail() throws Exception{
section="My Account Detail";
finalXpath="//*[contains(local-name(),'h') and contains(text(),\"My Account Detail\") and local-name()!='option']/ancestor::div[1]/following-sibling::div[1]";
return this;
}
 
 public  MyAccountScreen section_MyAccountEdit() throws Exception{
section="My Account Edit";
finalXpath="//*[contains(local-name(),'h') and contains(text(),\"My Account Edit\") and local-name()!='option']/ancestor::div[1]/following-sibling::div[1]";
return this;
}
 
 public  MyAccountScreen section_Information() throws Exception{
section="Information";
finalXpath="//*[contains(local-name(),'h') and contains(text(),\"Information\") and local-name()!='option']/ancestor::div[1]/following-sibling::div[1]";
return this;
}

}