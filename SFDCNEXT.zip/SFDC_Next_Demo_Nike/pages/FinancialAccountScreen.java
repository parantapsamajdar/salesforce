package pages;
import SFDC.SeleniumWrapper;
import supportlibraries.ScriptHelper;
public class FinancialAccountScreen extends SeleniumWrapper {
private String fieldName="";
private String finalXpath="";
private String section="";
public FinancialAccountScreen(ScriptHelper scriptHelper) {
super(scriptHelper);
	this.scriptHelper=scriptHelper;
	}

 
 public  WebElementMethods FinancialAccountNumbertext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Financial Account Number\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Financial Account Number";
else
fieldName="text: Financial Account Number";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods OwnerLink() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Owner\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//a[text()!='']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Link: Owner";
else
fieldName="Link: Owner";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods OwnerImage() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Owner\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//img";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Image: Owner";
else
fieldName="Image: Owner";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods Ownertext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Owner\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Owner";
else
fieldName="text: Owner";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods AccountLink() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Account\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//a[text()!='']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Link: Account";
else
fieldName="Link: Account";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods Accounttext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Account\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Account";
else
fieldName="text: Account";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods FinancialAccountTypetext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Financial Account Type\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Financial Account Type";
else
fieldName="text: Financial Account Type";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods LastBalanceUpdatedtext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Last Balance Updated\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Last Balance Updated";
else
fieldName="text: Last Balance Updated";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods FinancialAccountCreationDatetext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Financial Account Creation Date\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Financial Account Creation Date";
else
fieldName="text: Financial Account Creation Date";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods AccountBalancetext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Account Balance\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Account Balance";
else
fieldName="text: Account Balance";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods CreatedByLink() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Created By\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//a[text()!='']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Link: Created By";
else
fieldName="Link: Created By";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods CreatedBytext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Created By\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Created By";
else
fieldName="text: Created By";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods LastModifiedByLink() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Last Modified By\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//a[text()!='']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Link: Last Modified By";
else
fieldName="Link: Last Modified By";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods LastModifiedBytext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Last Modified By\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Last Modified By";
else
fieldName="text: Last Modified By";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods AccountTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Account\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Account";
else
fieldName="Text Box: Account";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods AccountImage() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Account\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//img";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Image: Account";
else
fieldName="Image: Account";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods FinancialAccountTypeDropDown() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Financial Account Type\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//select";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",DropDown: Financial Account Type";
else
fieldName="DropDown: Financial Account Type";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods LastBalanceUpdatedTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Last Balance Updated\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Last Balance Updated";
else
fieldName="Text Box: Last Balance Updated";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods LastBalanceUpdatedLink() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Last Balance Updated\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//a[text()!='']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Link: Last Balance Updated";
else
fieldName="Link: Last Balance Updated";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods FinancialAccountCreationDateTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Financial Account Creation Date\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Financial Account Creation Date";
else
fieldName="Text Box: Financial Account Creation Date";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods FinancialAccountCreationDateLink() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Financial Account Creation Date\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//a[text()!='']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Link: Financial Account Creation Date";
else
fieldName="Link: Financial Account Creation Date";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods AccountBalanceTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Account Balance\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Account Balance";
else
fieldName="Text Box: Account Balance";
section="";
return findElementByXpath(tempxpath, fieldName);
}
public  WebElementMethods element() throws Exception{
return findElementByXpath(finalXpath,"");
}

 
 public  WebElementMethods NewButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='New') and contains(@class,'btn')])[1]","Button:New");
}
 
 public  WebElementMethods GoButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Go!') and contains(@class,'btn')])[1]","Button:Go!");
}
 
 public  WebElementMethods RejectButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Reject') and contains(@class,'btn')])[1]","Button:Reject");
}
 
 public  WebElementMethods ApproveButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Approve') and contains(@class,'btn')])[1]","Button:Approve");
}
 
 public  WebElementMethods SaveButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Save') and contains(@class,'btn')])[1]","Button:Save");
}
 
 public  WebElementMethods CancelButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Cancel') and contains(@class,'btn')])[1]","Button:Cancel");
}
 
 public  WebElementMethods EditButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Edit') and contains(@class,'btn')])[1]","Button:Edit");
}
 
 public  WebElementMethods DeleteButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Delete') and contains(@class,'btn')])[1]","Button:Delete");
}
 
 public  WebElementMethods CloneButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Clone') and contains(@class,'btn')])[1]","Button:Clone");
}
 
 public  WebElementMethods SaveNewButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Save & New') and contains(@class,'btn')])[1]","Button:Save & New");
}
 
 public  FinancialAccountScreen section_FinancialAccountDetail() throws Exception{
section="Financial Account Detail";
finalXpath="//*[contains(local-name(),'h') and contains(text(),\"Financial Account Detail\") and local-name()!='option']/ancestor::div[1]/following-sibling::div[1]";
return this;
}
 
 public  FinancialAccountScreen section_FinancialAccountEdit() throws Exception{
section="Financial Account Edit";
finalXpath="//*[contains(local-name(),'h') and contains(text(),\"Financial Account Edit\") and local-name()!='option']/ancestor::div[1]/following-sibling::div[1]";
return this;
}
 
 public  FinancialAccountScreen section_Information() throws Exception{
section="Information";
finalXpath="//*[contains(local-name(),'h') and contains(text(),\"Information\") and local-name()!='option']/ancestor::div[1]/following-sibling::div[1]";
return this;
}

}