package pages;
import SFDC.SeleniumWrapper;
import supportlibraries.ScriptHelper;
public class AccountScreen extends SeleniumWrapper {
private String fieldName="";
private String finalXpath="";
private String section="";
public AccountScreen(ScriptHelper scriptHelper) {
super(scriptHelper);
	this.scriptHelper=scriptHelper;
	}

 
 public  WebElementMethods AccountOwnerLink() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Account Owner\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//a[text()!='']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Link: Account Owner";
else
fieldName="Link: Account Owner";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods AccountOwnerImage() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Account Owner\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//img";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Image: Account Owner";
else
fieldName="Image: Account Owner";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods AccountOwnertext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Account Owner\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Account Owner";
else
fieldName="text: Account Owner";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods Ratingtext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Rating\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Rating";
else
fieldName="text: Rating";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods AccountNameCheckbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Account Name\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]//input[@type='checkbox']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Check Box: Account Name";
else
fieldName="Check Box: Account Name";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods PhoneCheckbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Phone\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]//input[@type='checkbox']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Check Box: Phone";
else
fieldName="Check Box: Phone";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods ParentAccounttext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Parent Account\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Parent Account";
else
fieldName="text: Parent Account";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods Faxtext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Fax\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Fax";
else
fieldName="text: Fax";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods AccountNumbertext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Account Number\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Account Number";
else
fieldName="text: Account Number";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods Websitetext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Website\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Website";
else
fieldName="text: Website";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods AccountSitetext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Account Site\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Account Site";
else
fieldName="text: Account Site";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods TickerSymboltext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Ticker Symbol\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Ticker Symbol";
else
fieldName="text: Ticker Symbol";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods Typetext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Type\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Type";
else
fieldName="text: Type";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods Ownershiptext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Ownership\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Ownership";
else
fieldName="text: Ownership";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods Industrytext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Industry\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Industry";
else
fieldName="text: Industry";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods Employeestext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Employees\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Employees";
else
fieldName="text: Employees";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods AnnualRevenuetext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Annual Revenue\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Annual Revenue";
else
fieldName="text: Annual Revenue";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods SICCodetext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"SIC Code\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: SIC Code";
else
fieldName="text: SIC Code";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods BillingAddresstext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Billing Address\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Billing Address";
else
fieldName="text: Billing Address";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods ShippingAddresstext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Shipping Address\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Shipping Address";
else
fieldName="text: Shipping Address";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods CustomerPrioritytext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Customer Priority\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Customer Priority";
else
fieldName="text: Customer Priority";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods SLAtext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"SLA\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: SLA";
else
fieldName="text: SLA";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods SLAExpirationDatetext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"SLA Expiration Date\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: SLA Expiration Date";
else
fieldName="text: SLA Expiration Date";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods SLASerialNumbertext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"SLA Serial Number\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: SLA Serial Number";
else
fieldName="text: SLA Serial Number";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods NumberofLocationstext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Number of Locations\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Number of Locations";
else
fieldName="text: Number of Locations";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods UpsellOpportunitytext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Upsell Opportunity\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Upsell Opportunity";
else
fieldName="text: Upsell Opportunity";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods Activetext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Active\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Active";
else
fieldName="text: Active";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods CreatedByLink() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Created By\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//a[text()!='']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Link: Created By";
else
fieldName="Link: Created By";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods CreatedBytext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Created By\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Created By";
else
fieldName="text: Created By";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods LastModifiedByLink() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Last Modified By\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//a[text()!='']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Link: Last Modified By";
else
fieldName="Link: Last Modified By";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods LastModifiedBytext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Last Modified By\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Last Modified By";
else
fieldName="text: Last Modified By";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods DescriptionCheckbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Description\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]//input[@type='checkbox']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Check Box: Description";
else
fieldName="Check Box: Description";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods CustomLinksLink() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Custom Links\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//a[text()!='']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Link: Custom Links";
else
fieldName="Link: Custom Links";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods CustomLinkstext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Custom Links\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Custom Links";
else
fieldName="text: Custom Links";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public ContactsRelatedListfields relatedList_ContactsRelatedListfields() throws Exception{

return new ContactsRelatedListfields("Contacts");
}
 public class ContactsRelatedListfields{ 
String relatedListXpath="";
String RLName="";public ContactsRelatedListfields(String RelatedListSectionName){
relatedListXpath="(//h3[contains(text(),\"Contacts\") and local-name()!='option'])[1]/ancestor-or-self::div[1]/following-sibling::div[1]";
RLName="Related List: "+RelatedListSectionName;
}

public  WebElementMethods  showMoreLink() throws Exception{
RLName+=",showmore �";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"more �\")]",RLName);
}

public  WebElementMethods goToListLink() throws Exception{
RLName+=",Go to list";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"Go to list\")]",RLName);
}

public  WebElementMethods fieldHasText(String text) throws Exception{
RLName+=",Link/Text: "+text;
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\""+text+"\")]",RLName);
}

public  WebElementMethods Norecordstodisplaytext() throws Exception{
RLName+=",No records to display";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"No records to display\")]",RLName);
}
}

 
 public OpportunitiesRelatedListfields relatedList_OpportunitiesRelatedListfields() throws Exception{

return new OpportunitiesRelatedListfields("Opportunities");
}
 public class OpportunitiesRelatedListfields{ 
String relatedListXpath="";
String RLName="";public OpportunitiesRelatedListfields(String RelatedListSectionName){
relatedListXpath="(//h3[contains(text(),\"Opportunities\") and local-name()!='option'])[1]/ancestor-or-self::div[1]/following-sibling::div[1]";
RLName="Related List: "+RelatedListSectionName;
}

public  WebElementMethods  showMoreLink() throws Exception{
RLName+=",showmore �";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"more �\")]",RLName);
}

public  WebElementMethods goToListLink() throws Exception{
RLName+=",Go to list";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"Go to list\")]",RLName);
}

public  WebElementMethods fieldHasText(String text) throws Exception{
RLName+=",Link/Text: "+text;
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\""+text+"\")]",RLName);
}

public  WebElementMethods Norecordstodisplaytext() throws Exception{
RLName+=",No records to display";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"No records to display\")]",RLName);
}
}

 
 public CasesRelatedListfields relatedList_CasesRelatedListfields() throws Exception{

return new CasesRelatedListfields("Cases");
}
 public class CasesRelatedListfields{ 
String relatedListXpath="";
String RLName="";public CasesRelatedListfields(String RelatedListSectionName){
relatedListXpath="(//h3[contains(text(),\"Cases\") and local-name()!='option'])[1]/ancestor-or-self::div[1]/following-sibling::div[1]";
RLName="Related List: "+RelatedListSectionName;
}

public  WebElementMethods  showMoreLink() throws Exception{
RLName+=",showmore �";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"more �\")]",RLName);
}

public  WebElementMethods goToListLink() throws Exception{
RLName+=",Go to list";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"Go to list\")]",RLName);
}

public  WebElementMethods fieldHasText(String text) throws Exception{
RLName+=",Link/Text: "+text;
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\""+text+"\")]",RLName);
}

public  WebElementMethods Norecordstodisplaytext() throws Exception{
RLName+=",No records to display";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"No records to display\")]",RLName);
}
}

 
 public OpenActivitiesRelatedListfields relatedList_OpenActivitiesRelatedListfields() throws Exception{

return new OpenActivitiesRelatedListfields("OpenActivities");
}
 public class OpenActivitiesRelatedListfields{ 
String relatedListXpath="";
String RLName="";public OpenActivitiesRelatedListfields(String RelatedListSectionName){
relatedListXpath="(//h3[contains(text(),\"Open Activities\") and local-name()!='option'])[1]/ancestor-or-self::div[1]/following-sibling::div[1]";
RLName="Related List: "+RelatedListSectionName;
}

public  WebElementMethods  showMoreLink() throws Exception{
RLName+=",showmore �";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"more �\")]",RLName);
}

public  WebElementMethods goToListLink() throws Exception{
RLName+=",Go to list";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"Go to list\")]",RLName);
}

public  WebElementMethods fieldHasText(String text) throws Exception{
RLName+=",Link/Text: "+text;
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\""+text+"\")]",RLName);
}

public  WebElementMethods Norecordstodisplaytext() throws Exception{
RLName+=",No records to display";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"No records to display\")]",RLName);
}
}

 
 public ActivityHistoryRelatedListfields relatedList_ActivityHistoryRelatedListfields() throws Exception{

return new ActivityHistoryRelatedListfields("ActivityHistory");
}
 public class ActivityHistoryRelatedListfields{ 
String relatedListXpath="";
String RLName="";public ActivityHistoryRelatedListfields(String RelatedListSectionName){
relatedListXpath="(//h3[contains(text(),\"Activity History\") and local-name()!='option'])[1]/ancestor-or-self::div[1]/following-sibling::div[1]";
RLName="Related List: "+RelatedListSectionName;
}

public  WebElementMethods  showMoreLink() throws Exception{
RLName+=",showmore �";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"more �\")]",RLName);
}

public  WebElementMethods goToListLink() throws Exception{
RLName+=",Go to list";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"Go to list\")]",RLName);
}

public  WebElementMethods fieldHasText(String text) throws Exception{
RLName+=",Link/Text: "+text;
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\""+text+"\")]",RLName);
}

public  WebElementMethods Norecordstodisplaytext() throws Exception{
RLName+=",No records to display";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"No records to display\")]",RLName);
}
}

 
 public NotesAttachmentsRelatedListfields relatedList_NotesAttachmentsRelatedListfields() throws Exception{

return new NotesAttachmentsRelatedListfields("NotesAttachments");
}
 public class NotesAttachmentsRelatedListfields{ 
String relatedListXpath="";
String RLName="";public NotesAttachmentsRelatedListfields(String RelatedListSectionName){
relatedListXpath="(//h3[contains(text(),\"Notes & Attachments\") and local-name()!='option'])[1]/ancestor-or-self::div[1]/following-sibling::div[1]";
RLName="Related List: "+RelatedListSectionName;
}

public  WebElementMethods  showMoreLink() throws Exception{
RLName+=",showmore �";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"more �\")]",RLName);
}

public  WebElementMethods goToListLink() throws Exception{
RLName+=",Go to list";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"Go to list\")]",RLName);
}

public  WebElementMethods fieldHasText(String text) throws Exception{
RLName+=",Link/Text: "+text;
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\""+text+"\")]",RLName);
}

public  WebElementMethods Norecordstodisplaytext() throws Exception{
RLName+=",No records to display";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"No records to display\")]",RLName);
}
}

 
 public PartnersRelatedListfields relatedList_PartnersRelatedListfields() throws Exception{

return new PartnersRelatedListfields("Partners");
}
 public class PartnersRelatedListfields{ 
String relatedListXpath="";
String RLName="";public PartnersRelatedListfields(String RelatedListSectionName){
relatedListXpath="(//h3[contains(text(),\"Partners\") and local-name()!='option'])[1]/ancestor-or-self::div[1]/following-sibling::div[1]";
RLName="Related List: "+RelatedListSectionName;
}

public  WebElementMethods  showMoreLink() throws Exception{
RLName+=",showmore �";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"more �\")]",RLName);
}

public  WebElementMethods goToListLink() throws Exception{
RLName+=",Go to list";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"Go to list\")]",RLName);
}

public  WebElementMethods fieldHasText(String text) throws Exception{
RLName+=",Link/Text: "+text;
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\""+text+"\")]",RLName);
}

public  WebElementMethods Norecordstodisplaytext() throws Exception{
RLName+=",No records to display";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"No records to display\")]",RLName);
}
}

 
 public FinancialAccountRelatedListfields relatedList_FinancialAccountRelatedListfields() throws Exception{

return new FinancialAccountRelatedListfields("FinancialAccount");
}
 public class FinancialAccountRelatedListfields{ 
String relatedListXpath="";
String RLName="";public FinancialAccountRelatedListfields(String RelatedListSectionName){
relatedListXpath="(//h3[contains(text(),\"Financial Account\") and local-name()!='option'])[1]/ancestor-or-self::div[1]/following-sibling::div[1]";
RLName="Related List: "+RelatedListSectionName;
}

public  WebElementMethods  showMoreLink() throws Exception{
RLName+=",showmore �";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"more �\")]",RLName);
}

public  WebElementMethods goToListLink() throws Exception{
RLName+=",Go to list";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"Go to list\")]",RLName);
}

public  WebElementMethods fieldHasText(String text) throws Exception{
RLName+=",Link/Text: "+text;
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\""+text+"\")]",RLName);
}

public  WebElementMethods Norecordstodisplaytext() throws Exception{
RLName+=",No records to display";
 return findElementByXpath(""+relatedListXpath+"//*[contains(text(),\"No records to display\")]",RLName);
}
}

 
 public  WebElementMethods RatingDropDown() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Rating\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//select";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",DropDown: Rating";
else
fieldName="DropDown: Rating";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods AccountNameTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Account Name\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Account Name";
else
fieldName="Text Box: Account Name";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods AccountNametext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Account Name\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Account Name";
else
fieldName="text: Account Name";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods PhoneTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Phone\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Phone";
else
fieldName="Text Box: Phone";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods Phonetext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Phone\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Phone";
else
fieldName="text: Phone";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods ParentAccountTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Parent Account\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Parent Account";
else
fieldName="Text Box: Parent Account";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods ParentAccountImage() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Parent Account\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//img";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Image: Parent Account";
else
fieldName="Image: Parent Account";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods FaxTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Fax\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Fax";
else
fieldName="Text Box: Fax";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods AccountNumberTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Account Number\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Account Number";
else
fieldName="Text Box: Account Number";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods WebsiteTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Website\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Website";
else
fieldName="Text Box: Website";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods AccountSiteTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Account Site\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Account Site";
else
fieldName="Text Box: Account Site";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods TickerSymbolTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Ticker Symbol\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Ticker Symbol";
else
fieldName="Text Box: Ticker Symbol";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods TypeDropDown() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Type\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//select";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",DropDown: Type";
else
fieldName="DropDown: Type";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods OwnershipDropDown() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Ownership\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//select";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",DropDown: Ownership";
else
fieldName="DropDown: Ownership";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods IndustryDropDown() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Industry\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//select";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",DropDown: Industry";
else
fieldName="DropDown: Industry";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods EmployeesTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Employees\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Employees";
else
fieldName="Text Box: Employees";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods AnnualRevenueTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Annual Revenue\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Annual Revenue";
else
fieldName="Text Box: Annual Revenue";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods SICCodeTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"SIC Code\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: SIC Code";
else
fieldName="Text Box: SIC Code";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods BillingStreetTextArea() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Billing Street\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//textarea";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",TextArea: Billing Street";
else
fieldName="TextArea: Billing Street";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods BillingStreettext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Billing Street\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Billing Street";
else
fieldName="text: Billing Street";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods ShippingStreetTextArea() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Shipping Street\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//textarea";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",TextArea: Shipping Street";
else
fieldName="TextArea: Shipping Street";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods ShippingStreettext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Shipping Street\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Shipping Street";
else
fieldName="text: Shipping Street";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods BillingCityTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Billing City\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Billing City";
else
fieldName="Text Box: Billing City";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods BillingCitytext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Billing City\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Billing City";
else
fieldName="text: Billing City";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods ShippingCityTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Shipping City\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Shipping City";
else
fieldName="Text Box: Shipping City";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods ShippingCitytext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Shipping City\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Shipping City";
else
fieldName="text: Shipping City";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods BillingStateProvinceTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Billing State/Province\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Billing State/Province";
else
fieldName="Text Box: Billing State/Province";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods BillingStateProvincetext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Billing State/Province\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Billing State/Province";
else
fieldName="text: Billing State/Province";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods ShippingStateProvinceTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Shipping State/Province\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Shipping State/Province";
else
fieldName="Text Box: Shipping State/Province";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods ShippingStateProvincetext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Shipping State/Province\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Shipping State/Province";
else
fieldName="text: Shipping State/Province";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods BillingZipPostalCodeTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Billing Zip/Postal Code\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Billing Zip/Postal Code";
else
fieldName="Text Box: Billing Zip/Postal Code";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods BillingZipPostalCodetext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Billing Zip/Postal Code\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Billing Zip/Postal Code";
else
fieldName="text: Billing Zip/Postal Code";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods ShippingZipPostalCodeTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Shipping Zip/Postal Code\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Shipping Zip/Postal Code";
else
fieldName="Text Box: Shipping Zip/Postal Code";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods ShippingZipPostalCodetext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Shipping Zip/Postal Code\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Shipping Zip/Postal Code";
else
fieldName="text: Shipping Zip/Postal Code";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods BillingCountryTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Billing Country\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Billing Country";
else
fieldName="Text Box: Billing Country";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods BillingCountrytext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Billing Country\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Billing Country";
else
fieldName="text: Billing Country";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods ShippingCountryTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Shipping Country\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Shipping Country";
else
fieldName="Text Box: Shipping Country";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods ShippingCountrytext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Shipping Country\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Shipping Country";
else
fieldName="text: Shipping Country";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods CustomerPriorityDropDown() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Customer Priority\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//select";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",DropDown: Customer Priority";
else
fieldName="DropDown: Customer Priority";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods SLADropDown() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"SLA\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//select";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",DropDown: SLA";
else
fieldName="DropDown: SLA";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods SLAExpirationDateTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"SLA Expiration Date\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: SLA Expiration Date";
else
fieldName="Text Box: SLA Expiration Date";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods SLAExpirationDateLink() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"SLA Expiration Date\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//a[text()!='']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Link: SLA Expiration Date";
else
fieldName="Link: SLA Expiration Date";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods SLASerialNumberTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"SLA Serial Number\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: SLA Serial Number";
else
fieldName="Text Box: SLA Serial Number";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods NumberofLocationsTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Number of Locations\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Number of Locations";
else
fieldName="Text Box: Number of Locations";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods UpsellOpportunityDropDown() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Upsell Opportunity\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//select";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",DropDown: Upsell Opportunity";
else
fieldName="DropDown: Upsell Opportunity";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods ActiveDropDown() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Active\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//select";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",DropDown: Active";
else
fieldName="DropDown: Active";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods DescriptionTextArea() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Description\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//textarea";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",TextArea: Description";
else
fieldName="TextArea: Description";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods Descriptiontext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Description\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Description";
else
fieldName="text: Description";
section="";
return findElementByXpath(tempxpath, fieldName);
}
public  WebElementMethods element() throws Exception{
return findElementByXpath(finalXpath,"");
}

 
 public  WebElementMethods NewButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='New') and contains(@class,'btn')])[1]","Button:New");
}
 
 public  WebElementMethods GoButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Go!') and contains(@class,'btn')])[1]","Button:Go!");
}
 
 public  WebElementMethods RejectButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Reject') and contains(@class,'btn')])[1]","Button:Reject");
}
 
 public  WebElementMethods ApproveButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Approve') and contains(@class,'btn')])[1]","Button:Approve");
}
 
 public  WebElementMethods ShareButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Share') and contains(@class,'btn')])[1]","Button:Share");
}
 
 public  WebElementMethods SaveButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Save') and contains(@class,'btn')])[1]","Button:Save");
}
 
 public  WebElementMethods CancelButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Cancel') and contains(@class,'btn')])[1]","Button:Cancel");
}
 
 public  WebElementMethods EditButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Edit') and contains(@class,'btn')])[1]","Button:Edit");
}
 
 public  WebElementMethods DeleteButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Delete') and contains(@class,'btn')])[1]","Button:Delete");
}
 
 public  WebElementMethods IncludeOfflineButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Include Offline') and contains(@class,'btn')])[1]","Button:Include Offline");
}
 
 public  WebElementMethods NewContactButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='New Contact') and contains(@class,'btn')])[1]","Button:New Contact");
}
 
 public  WebElementMethods MergeContactsButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Merge Contacts') and contains(@class,'btn')])[1]","Button:Merge Contacts");
}
 
 public  WebElementMethods NewOpportunityButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='New Opportunity') and contains(@class,'btn')])[1]","Button:New Opportunity");
}
 
 public  WebElementMethods NewCaseButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='New Case') and contains(@class,'btn')])[1]","Button:New Case");
}
 
 public  WebElementMethods NewTaskButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='New Task') and contains(@class,'btn')])[1]","Button:New Task");
}
 
 public  WebElementMethods NewEventButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='New Event') and contains(@class,'btn')])[1]","Button:New Event");
}
 
 public  WebElementMethods LogaCallButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Log a Call') and contains(@class,'btn')])[1]","Button:Log a Call");
}
 
 public  WebElementMethods MailMergeButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Mail Merge') and contains(@class,'btn')])[1]","Button:Mail Merge");
}
 
 public  WebElementMethods SendanEmailButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Send an Email') and contains(@class,'btn')])[1]","Button:Send an Email");
}
 
 public  WebElementMethods NewNoteButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='New Note') and contains(@class,'btn')])[1]","Button:New Note");
}
 
 public  WebElementMethods AttachFileButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Attach File') and contains(@class,'btn')])[1]","Button:Attach File");
}
 
 public  WebElementMethods NewFinancialAccountButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='New Financial Account') and contains(@class,'btn')])[1]","Button:New Financial Account");
}
 
 public  WebElementMethods OKButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='OK') and contains(@class,'btn')])[1]","Button:OK");
}
 
 public  WebElementMethods SaveNewButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Save & New') and contains(@class,'btn')])[1]","Button:Save & New");
}
 
 public  AccountScreen section_AccountDetail() throws Exception{
section="Account Detail";
finalXpath="//*[contains(local-name(),'h') and contains(text(),\"Account Detail\") and local-name()!='option']/ancestor::div[1]/following-sibling::div[1]";
return this;
}
 
 public  AccountScreen section_AccountEdit() throws Exception{
section="Account Edit";
finalXpath="//*[contains(local-name(),'h') and contains(text(),\"Account Edit\") and local-name()!='option']/ancestor::div[1]/following-sibling::div[1]";
return this;
}
 
 public  AccountScreen section_AccountInformation() throws Exception{
section="Account Information";
finalXpath="//*[contains(local-name(),'h') and contains(text(),\"Account Information\") and local-name()!='option']/ancestor::div[1]/following-sibling::div[1]";
return this;
}
 
 public  AccountScreen section_AddressInformation() throws Exception{
section="Address Information";
finalXpath="//*[contains(local-name(),'h') and contains(text(),\"Address Information\") and local-name()!='option']/ancestor::div[1]/following-sibling::div[1]";
return this;
}
 
 public  AccountScreen section_AdditionalInformation() throws Exception{
section="Additional Information";
finalXpath="//*[contains(local-name(),'h') and contains(text(),\"Additional Information\") and local-name()!='option']/ancestor::div[1]/following-sibling::div[1]";
return this;
}
 
 public  AccountScreen section_DescriptionInformation() throws Exception{
section="Description Information";
finalXpath="//*[contains(local-name(),'h') and contains(text(),\"Description Information\") and local-name()!='option']/ancestor::div[1]/following-sibling::div[1]";
return this;
}

}