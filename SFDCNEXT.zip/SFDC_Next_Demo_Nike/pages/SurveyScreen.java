package pages;
import SFDC.SeleniumWrapper;
import supportlibraries.ScriptHelper;
public class SurveyScreen extends SeleniumWrapper {
private String fieldName="";
private String finalXpath="";
private String section="";
public SurveyScreen(ScriptHelper scriptHelper) {
super(scriptHelper);
	this.scriptHelper=scriptHelper;
	}

 
 public  WebElementMethods SurveyNametext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Survey Name\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Survey Name";
else
fieldName="text: Survey Name";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods OwnerLink() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Owner\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//a[text()!='']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Link: Owner";
else
fieldName="Link: Owner";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods OwnerImage() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Owner\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//img";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Image: Owner";
else
fieldName="Image: Owner";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods Ownertext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Owner\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Owner";
else
fieldName="text: Owner";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods StartDatetext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Start Date\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Start Date";
else
fieldName="text: Start Date";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods EndDatetext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"End Date\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: End Date";
else
fieldName="text: End Date";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods SurveyAssignmentLink() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Survey Assignment\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//a[text()!='']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Link: Survey Assignment";
else
fieldName="Link: Survey Assignment";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods SurveyAssignmenttext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Survey Assignment\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Survey Assignment";
else
fieldName="text: Survey Assignment";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods SurveyTypetext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Survey Type\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Survey Type";
else
fieldName="text: Survey Type";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods SurveyStatustext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Survey Status\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Survey Status";
else
fieldName="text: Survey Status";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods Feedbacktext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Feedback\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Feedback";
else
fieldName="text: Feedback";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods CreatedByLink() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Created By\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//a[text()!='']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Link: Created By";
else
fieldName="Link: Created By";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods CreatedBytext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Created By\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Created By";
else
fieldName="text: Created By";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods LastModifiedByLink() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Last Modified By\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//a[text()!='']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Link: Last Modified By";
else
fieldName="Link: Last Modified By";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods LastModifiedBytext() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Last Modified By\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",text: Last Modified By";
else
fieldName="text: Last Modified By";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods SurveyNameTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Survey Name\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Survey Name";
else
fieldName="Text Box: Survey Name";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods StartDateTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Start Date\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Start Date";
else
fieldName="Text Box: Start Date";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods StartDateLink() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Start Date\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//a[text()!='']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Link: Start Date";
else
fieldName="Link: Start Date";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods EndDateTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"End Date\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: End Date";
else
fieldName="Text Box: End Date";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods EndDateLink() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"End Date\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//a[text()!='']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Link: End Date";
else
fieldName="Link: End Date";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods SurveyAssignmentTextbox() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Survey Assignment\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//input[@type='text']";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Text Box: Survey Assignment";
else
fieldName="Text Box: Survey Assignment";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods SurveyAssignmentImage() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Survey Assignment\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//img";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",Image: Survey Assignment";
else
fieldName="Image: Survey Assignment";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods SurveyTypeDropDown() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Survey Type\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//select";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",DropDown: Survey Type";
else
fieldName="DropDown: Survey Type";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods SurveyStatusDropDown() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Survey Status\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//select";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",DropDown: Survey Status";
else
fieldName="DropDown: Survey Status";
section="";
return findElementByXpath(tempxpath, fieldName);
}
 
 public  WebElementMethods FeedbackTextArea() throws Exception{
String tempxpath="("+finalXpath+"//*[text()=\"Feedback\" and local-name()!='option' and (local-name()='td' or local-name()='th' or local-name()='label')])[1]/ancestor-or-self::*[starts-with(local-name(),'t')][1]/following-sibling::*[1]//textarea";
finalXpath="";
if(!section.equals(""))
fieldName="Section: "+section+",TextArea: Feedback";
else
fieldName="TextArea: Feedback";
section="";
return findElementByXpath(tempxpath, fieldName);
}
public  WebElementMethods element() throws Exception{
return findElementByXpath(finalXpath,"");
}

 
 public  WebElementMethods NewButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='New') and contains(@class,'btn')])[1]","Button:New");
}
 
 public  WebElementMethods GoButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Go!') and contains(@class,'btn')])[1]","Button:Go!");
}
 
 public  WebElementMethods RejectButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Reject') and contains(@class,'btn')])[1]","Button:Reject");
}
 
 public  WebElementMethods ApproveButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Approve') and contains(@class,'btn')])[1]","Button:Approve");
}
 
 public  WebElementMethods SaveButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Save') and contains(@class,'btn')])[1]","Button:Save");
}
 
 public  WebElementMethods CancelButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Cancel') and contains(@class,'btn')])[1]","Button:Cancel");
}
 
 public  WebElementMethods EditButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Edit') and contains(@class,'btn')])[1]","Button:Edit");
}
 
 public  WebElementMethods DeleteButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Delete') and contains(@class,'btn')])[1]","Button:Delete");
}
 
 public  WebElementMethods CloneButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Clone') and contains(@class,'btn')])[1]","Button:Clone");
}
 
 public  WebElementMethods OKButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='OK') and contains(@class,'btn')])[1]","Button:OK");
}
 
 public  WebElementMethods SaveNewButton() throws Exception{
return findElementByXpath("(//*[(normalize-space(@value)='Save & New') and contains(@class,'btn')])[1]","Button:Save & New");
}
 
 public  SurveyScreen section_SurveyDetail() throws Exception{
section="Survey Detail";
finalXpath="//*[contains(local-name(),'h') and contains(text(),\"Survey Detail\") and local-name()!='option']/ancestor::div[1]/following-sibling::div[1]";
return this;
}
 
 public  SurveyScreen section_SurveyEdit() throws Exception{
section="Survey Edit";
finalXpath="//*[contains(local-name(),'h') and contains(text(),\"Survey Edit\") and local-name()!='option']/ancestor::div[1]/following-sibling::div[1]";
return this;
}
 
 public  SurveyScreen section_Information() throws Exception{
section="Information";
finalXpath="//*[contains(local-name(),'h') and contains(text(),\"Information\") and local-name()!='option']/ancestor::div[1]/following-sibling::div[1]";
return this;
}

}